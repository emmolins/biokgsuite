#!/usr/bin/env python3
"""Merge the five per-regulator candidate tables into one long-format, pre-cleaning table.

One row = one regulator decision that (per that regulator's own classification, or a text match on its
free-text reason) adds an indication to an already-authorised product, 2023-01-01 to today. Nothing is
deduplicated across regulators and nothing is judged to be "true repurposing" here: that is the cleaning
step (ontology-mapping the old and new indications). Columns common to all sources come first; the
regulator-specific detail stays in interim/<regulator>_candidates.csv and is referenced by `source_row_id`.

Schema (candidates_precleaning.csv):
  candidate_id          <regulator>:<row id>  (FDA: appl_no-suppl_no; EMA: meeting-slug:medicine; HC: NOC number;
                        PMDA: date:row_no; TGA: page slug)
  regulator             FDA | EMA | HC | PMDA | TGA
  event_date            ISO date of the regulator's decision (FDA supplement approval, CHMP opinion date, NOC date,
                        PMDA approval date, TGA decision date)
  event_type            regulator's own label for the decision (see per-source notes in README)
  product_name          brand / product name(s) as printed by the regulator
  active_ingredient     active ingredient(s) as printed by the regulator (not yet normalised)
  sponsor               applicant / MAH / sponsor
  indication_text       new indication text when the regulator publishes it (TGA always; HC when the reason field
                        quotes it; PMDA summary phrase; FDA: the approval letter's "provides for" sentence from
                        interim/fda_letter_indications.csv; EMA: the variation scope from the EPAR procedural-steps
                        PDF, interim/ema_procedural_indications.csv; empty when neither is available)
  classification_flag   what makes this row a candidate: 'new_indication' (regulator coded it), 'text_match'
                        (regex on free text), 'unclassified' (efficacy supplement with no sub-type available yet)
  classification_source where the flag came from
  regulatory_pathway_flags  orphan / priority / accelerated / provisional / conditional, as available
  source_url            page or document the row was taken from
  document_url          label / letter / EPAR / NOC page when available
  source_row_id         key into the per-regulator interim CSV
  notes                 free text carried from the source (FDA: Drugs@FDA categories; PMDA: Notes column; HC: reason)

Usage:
    python scripts/merge_candidates.py -o data/candidates_precleaning.csv
"""
import argparse
import csv
import re
from pathlib import Path

FIELDS = ["candidate_id", "regulator", "event_date", "event_type", "product_name", "active_ingredient", "sponsor",
          "indication_text", "classification_flag", "classification_source", "regulatory_pathway_flags",
          "source_url", "document_url", "source_row_id", "notes"]


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def optional_index(path, key):
    """{key: row} for an interim table that may not exist yet (letter / EPAR text steps)."""
    p = Path(path)
    return {r[key]: r for r in read(p)} if p.exists() else {}


FDA_LETTERS = optional_index("interim/fda_letter_indications.csv", "candidate_id")
EMA_STEPS = optional_index("interim/ema_procedural_indications.csv", "source_row_id")


def fda_rows(path):
    for r in read(path):
        if r["is_new_indication_any"] == "True":
            flag, src = "new_indication", r["subtype_source"]
        elif r["subtype_source"] == "none":
            flag, src = "unclassified", "efficacy supplement; sub-type not yet published (2026 BLA)"
        else:
            continue  # efficacy supplement of another sub-type (dosing, population, labeling ...)
        etype = r["supplement_type_pdf"] or r["supplement_type_drugsatfda"] or "Efficacy supplement (sub-type unknown)"
        cid = f"FDA:{r['appl_type']}{r['appl_no']}-S{r['suppl_no']}"
        letter = FDA_LETTERS.get(cid, {})
        yield {
            "candidate_id": cid,
            "regulator": "FDA", "event_date": r["approval_date"], "event_type": f"Efficacy supplement: {etype}",
            "product_name": r["brand_names"], "active_ingredient": r["active_ingredients"], "sponsor": r["sponsor"],
            # the approval letter's own statement of what the supplement provides for (scripts/fda_letter_indication.py)
            "indication_text": letter.get("provides_for", ""), "classification_flag": flag, "classification_source": src,
            "regulatory_pathway_flags": ("priority" if r["review_priority"] == "PRIORITY" else "") +
                                        ("; accelerated approval" if "Accelerated Approval" in r["supplement_categories_drugsatfda"] else ""),
            "source_url": r["drugsatfda_url"], "document_url": r["label_url"] or r["letter_url"],
            "source_row_id": f"{r['appl_no']}-{r['suppl_no']}",
            "notes": "; ".join(x for x in (
                f"drugsatfda categories: {r['supplement_categories_drugsatfda']}" if r["supplement_categories_drugsatfda"] else "",
                f"letter: {letter['letter_url']}" if letter.get("letter_url") else "",
                f"letter class guess: {letter['letter_class']}" if letter.get("letter_class") else "") if x),
        }


def ema_rows(path):
    seen = {}
    for r in read(path):
        flag = "new_indication" if r["opinion_polarity"] == "positive" and r["outside_eu"] != "True" else "excluded_" + (
            "outside_eu" if r["outside_eu"] == "True" else r["opinion_polarity"])
        slug = r["meeting_url"].rsplit("chmp-", 1)[-1]
        cid = f"EMA:{slug}:{re.sub(r'[^A-Za-z0-9]+', '-', r['medicine']).strip('-')}"
        seen[cid] = seen.get(cid, 0) + 1
        if seen[cid] > 1:  # one medicine, two extension opinions at the same meeting (e.g. Bimzelx II/0010 and II/0011, Apr 2023)
            cid += f"#{seen[cid]}"
        step = EMA_STEPS.get(f"{r['source_file']}:{r['medicine']}", {})
        yield {
            "candidate_id": cid,
            "regulator": "EMA", "event_date": r["chmp_opinion_published"],
            "event_type": f"CHMP opinion: {r['section']}",
            "product_name": r["medicine"], "active_ingredient": r["inn"], "sponsor": r["mah"],
            # scope of the variation from the EPAR procedural-steps PDF (scripts/ema_procedural_steps.py)
            "indication_text": step.get("scope_text", "") if step.get("matched") == "True" else "",
            "classification_flag": flag, "classification_source": "CHMP highlights section heading",
            "regulatory_pathway_flags": "", "source_url": r["meeting_url"],
            "document_url": step.get("doc_url") or r["epar_url"],
            "source_row_id": f"{r['source_file']}:{r['medicine']}",
            "notes": "; ".join(x for x in (
                r["more_information"],
                f"procedure {step['procedure_no']}" if step.get("procedure_no") else "",
                f"EC decision {step['decision_date']}" if step.get("decision_date") else "") if x),
        }


def hc_rows(path):
    for r in read(path):
        reason = r["reason_supplement"] or r["reason_submission"]
        m = re.search(r"^(new indication|additional indication|indication extension|expan\w+ (of )?(the )?indication|"
                      r"new indications|extension of indication)", reason.strip(), re.I)
        flag = "new_indication" if m else "text_match"
        yield {
            "candidate_id": f"HC:{r['noc_number']}", "regulator": "HC", "event_date": r["noc_date"],
            "event_type": f"{r['submission_type']} ({r['submission_class']})",
            "product_name": r["brand_names"], "active_ingredient": r["active_ingredients"], "sponsor": r["manufacturer"],
            "indication_text": reason, "classification_flag": flag,
            "classification_source": "NOC_ENG_REASON_SUPPLEMENT text" + (" (starts with a new-indication phrase)" if m else " (mentions 'indication')"),
            "regulatory_pathway_flags": ("priority; " if "Priority" in r["submission_class"] else "") + ("NOC/c" if r["noc_with_conditions"] == "Y" else ""),
            "source_url": r["noc_url"], "document_url": "", "source_row_id": r["noc_number"],
            "notes": f"product type: {r['product_type']}; therapeutic class: {r['therapeutic_class']}",
        }


def pmda_rows(path):
    for r in read(path):
        flag = "new_indication"
        if r["mentions_new_active_ingredient"] == "True":
            flag = "text_match"  # e.g. "(1) new active ingredient ... (2) new indication" combination rows
        yield {
            "candidate_id": f"PMDA:{r['approval_date']}:{r['row_no']}", "regulator": "PMDA", "event_date": r["approval_date"],
            "event_type": f"{r['approval_or_change']} ({r['fy_or_month_section']})",
            "product_name": r["brand_names"], "active_ingredient": r["active_ingredients"], "sponsor": r["applicant"],
            "indication_text": r["notes"], "classification_flag": flag, "classification_source": "Notes column mentions 'new indication'",
            "regulatory_pathway_flags": ("orphan" if r["orphan"] == "True" else "") + ("; priority" if "[Priority review]" in r["notes"] else ""),
            "source_url": "https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html",
            "document_url": "", "source_row_id": f"{r['source_pdf']}:p{r['page']}:{r['row_no']}",
            "notes": f"review category {r['review_category']}",
        }


def tga_rows(path):
    for r in read(path):
        yield {
            "candidate_id": f"TGA:{r['url'].rsplit('/', 1)[-1]}", "regulator": "TGA", "event_date": r["decision_date"],
            "event_type": "Extension of indications (EOI) registration",
            "product_name": r["product_name"], "active_ingredient": r["active_ingredients"], "sponsor": r["sponsor"],
            "indication_text": r["indication_text"], "classification_flag": "new_indication",
            "classification_source": "TGA registration type = EOI",
            "regulatory_pathway_flags": "; ".join(k for k, v in (("orphan", r["orphan"]), ("priority", r["priority_review"]), ("provisional", r["provisional"])) if v == "True"),
            "source_url": r["url"], "document_url": "", "source_row_id": r["url"].rsplit("/", 1)[-1],
            "notes": f"registered {r['date_registered']}; evaluation commenced {r['evaluation_commenced']}",
        }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--interim", default="interim")
    ap.add_argument("-o", "--out", default="data/candidates_precleaning.csv")
    a = ap.parse_args()
    i = Path(a.interim)
    rows = []
    rows += list(fda_rows(i / "fda_candidates.csv"))
    rows += list(ema_rows(i / "ema_candidates.csv"))
    rows += list(hc_rows(i / "health_canada_candidates.csv"))
    rows += list(pmda_rows(i / "pmda_candidates.csv"))
    rows += list(tga_rows(i / "tga_candidates.csv"))
    rows.sort(key=lambda r: (r["event_date"], r["regulator"], r["product_name"]))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    from collections import Counter
    c = Counter((r["regulator"], r["classification_flag"]) for r in rows)
    for k in sorted(c):
        print(f"{k[0]:5s} {k[1]:25s} {c[k]}")
    print(f"{len(rows)} rows -> {a.out}")


if __name__ == "__main__":
    main()
