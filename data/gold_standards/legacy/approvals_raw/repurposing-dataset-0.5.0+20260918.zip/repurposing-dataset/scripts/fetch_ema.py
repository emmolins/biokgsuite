#!/usr/bin/env python3
"""Fetch the EMA "Meeting highlights from the CHMP" news pages for every CHMP meeting since START_YEAR.

Discovery: the EMA news search https://www.ema.europa.eu/en/news?search_api_fulltext=Meeting+highlights+CHMP
lists one highlights page per meeting (about 11 per year; no August meeting). The page slug encodes the meeting
dates: /en/news/meeting-highlights-committee-medicinal-products-human-use-chmp-<d>-<d>-<month>-<yyyy>.
Each page is saved as raw/ema/chmp-highlights-<slug>.html with a small metadata comment on top; only the
content container (.ema-node-content-wrapper.node-sections) is kept, with scripts/styles/images removed, so
the files are small and diff-able. ema_parse_chmp_highlights.py reads these files.

Usage:
    python scripts/fetch_ema.py --start-year 2023 -o raw/ema
"""
import argparse
import re
from pathlib import Path

from bs4 import BeautifulSoup

from common import get, now_iso, session, write_manifest

SEARCH = "https://www.ema.europa.eu/en/news?search_api_fulltext=Meeting+highlights+CHMP&page={}"
SLUG_RE = re.compile(r"/en/news/meeting-highlights-committee-medicinal-products-human-use-chmp-([\w-]+-(\d{4}))$")
DROP_SECTIONS = ("Related content", "Contact point", "Share this page", "Other updates", "Related medicine information", "CHMP statistics")


def discover(s, start_year, max_pages=80):
    slugs = {}
    for p in range(max_pages):
        soup = BeautifulSoup(get(s, SEARCH.format(p)).text, "lxml")
        links = [a["href"] for a in soup.find_all("a", href=True)]
        if not any("/en/news/" in h for h in links):
            break
        years = []
        for h in links:
            m = SLUG_RE.search(h)
            if m:
                slugs[m.group(1)] = "https://www.ema.europa.eu" + h if h.startswith("/") else h
                years.append(int(m.group(2)))
        if years and max(years) < start_year:
            break
    return {k: v for k, v in slugs.items() if int(k[-4:]) >= start_year}


def slim(soup):
    wrapper = soup.select_one(".ema-node-content-wrapper.node-sections")
    if wrapper is None:
        return None
    for tag in wrapper.find_all(["script", "style", "svg", "img", "noscript", "iframe", "button"]):
        tag.decompose()
    for tag in wrapper.find_all(True):
        for attr in list(tag.attrs):
            if attr not in ("class", "id", "href"):
                del tag.attrs[attr]
    for tip in wrapper.select(".ema-tooltip"):
        tip.replace_with(tip.get_text())
    for item in list(wrapper.find_all(recursive=False)):
        if item.get_text(" ", strip=True).startswith(DROP_SECTIONS):
            item.decompose()
    return str(wrapper)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start-year", type=int, default=2023)
    ap.add_argument("-o", "--out", default="raw/ema")
    a = ap.parse_args()
    s = session()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    slugs = discover(s, a.start_year)
    print(f"{len(slugs)} CHMP highlight pages since {a.start_year}")
    pages = {}
    for slug, url in sorted(slugs.items(), key=lambda kv: kv[0][-4:]):
        soup = BeautifulSoup(get(s, url).text, "lxml")
        body = slim(soup)
        if body is None:
            print("no content wrapper:", url)
            continue
        title = soup.find("h1").get_text(" ", strip=True) if soup.find("h1") else slug
        t = soup.find("time")
        published = t.get("datetime", "") if t else ""
        header = f"<!-- source: {url}\n     title: {title}\n     published: {published}\n     fetched: {now_iso()}\n     note: .ema-node-content-wrapper.node-sections element of the page, with scripts/styles/images and non-content sections removed -->\n"
        (out / f"chmp-highlights-{slug}.html").write_text(header + body, encoding="utf-8")
        pages[slug] = {"url": url, "title": title, "published": published}
    write_manifest(out / "MANIFEST.json", pages=pages)


if __name__ == "__main__":
    main()
