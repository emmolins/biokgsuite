#!/usr/bin/env python3
"""Health Canada: candidate new-indication supplements from the Notice of Compliance (NOC) data extract.

Source (updated weekly, Open Government Licence - Canada):
  https://www.canada.ca/en/health-canada/services/drugs-health-products/drug-products/notice-compliance/database/data-extract.html
  Files: noc_main.txt, noc_brand.txt, noc_din_product.txt, noc_product_ingredient.txt (comma-delimited, quoted, no header)
  Field list: https://www.canada.ca/en/health-canada/services/drugs-health-products/drug-products/notice-compliance/database/read-file.html

Canada does not code supplements by type the way the FDA does (SE1 = new indication). The closest
equivalent is a Supplement to a New Drug Submission (SNDS) whose free-text reason
(NOC_ENG_REASON_SUPPLEMENT / NOC_ENG_REASON_SUBMISSION) mentions an indication. This script keeps
every SNDS in the date window whose reason text matches the regex below, so that the manual
classification step can decide between "new indication", "expanded indication", "removed indication", etc.

Usage:
    python scripts/health_canada_extract.py --raw raw/health_canada --start 2023-01-01 -o interim/health_canada_candidates.csv
"""
import argparse
import csv
import re
from collections import defaultdict
from datetime import date
from pathlib import Path

MAIN_FIELDS = [
    "NOC_NUMBER", "NOC_DATE", "NOC_MANUFACTURER_NAME", "NOC_STATUS_WITH_CONDITIONS",
    "NOC_ENG_SUBMISSION_TYPE", "NOC_FR_SUBMISSION_TYPE", "NOC_IS_SUPPLEMENT",
    "NOC_ENG_SUBMISSION_CLASS", "NOC_FR_SUBMISSION_CLASS", "NOC_ENG_PRODUCT_TYPE", "NOC_FR_PRODUCT_TYPE",
    "NOC_CRP_PRODUCT_NAME", "NOC_CRP_COMPANY_NAME", "NOC_CRP_COUNTRY_ENG_NAME", "NOC_CRP_COUNTRY_FR_NAME",
    "NOC_ACTIVE_STATUS", "NOC_ENG_REASON_SUPPLEMENT", "NOC_FR_REASON_SUPPLEMENT",
    "NOC_ENG_THERAPEUTIC_CLASS", "NOC_FR_THERAPEUTIC_CLASS", "NOC_ENG_REASON_SUBMISSION", "NOC_FR_REASON_SUBMISSION",
]
INDICATION_RE = re.compile(r"indication", re.IGNORECASE)
SNDS = "Supplement to a New Drug Submission (SNDS)"


def read_extract(path):
    with open(path, encoding="utf-8", errors="replace", newline="") as f:
        for row in csv.reader(f):
            if row:
                yield row


def noc_date(s):
    """NOC_DATE is YY-MM-DD in the extract."""
    yy, mm, dd = s.split("-")
    return date(2000 + int(yy), int(mm), int(dd))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="raw/health_canada")
    ap.add_argument("--start", default="2023-01-01")
    ap.add_argument("--end", default=date.today().isoformat())
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    raw = Path(a.raw)
    start, end = date.fromisoformat(a.start), date.fromisoformat(a.end)

    brands = defaultdict(list)
    for r in read_extract(raw / "noc_brand.txt"):
        brands[r[0]].append(r[2])
    ingredients = defaultdict(list)
    for r in read_extract(raw / "noc_product_ingredient.txt"):
        name = r[2].strip()
        if name and name not in ingredients[r[0]]:
            ingredients[r[0]].append(name)
    dins = defaultdict(list)
    for r in read_extract(raw / "noc_din_product.txt"):
        if r[3] and r[3] not in dins[r[0]]:
            dins[r[0]].append(r[3])

    out_rows = []
    n_snds = 0
    for r in read_extract(raw / "noc_main.txt"):
        rec = dict(zip(MAIN_FIELDS, r))
        d = noc_date(rec["NOC_DATE"])
        if not (start <= d <= end):
            continue
        if rec["NOC_ENG_SUBMISSION_TYPE"] != SNDS:
            continue
        n_snds += 1
        reason = (rec["NOC_ENG_REASON_SUPPLEMENT"] + " " + rec["NOC_ENG_REASON_SUBMISSION"]).strip()
        if not INDICATION_RE.search(reason):
            continue
        out_rows.append({
            "noc_number": rec["NOC_NUMBER"],
            "noc_date": d.isoformat(),
            "brand_names": "; ".join(sorted(set(brands.get(rec["NOC_NUMBER"], [])))),
            "active_ingredients": "; ".join(ingredients.get(rec["NOC_NUMBER"], [])),
            "dins": "; ".join(dins.get(rec["NOC_NUMBER"], [])),
            "manufacturer": rec["NOC_MANUFACTURER_NAME"],
            "submission_type": rec["NOC_ENG_SUBMISSION_TYPE"],
            "submission_class": rec["NOC_ENG_SUBMISSION_CLASS"],
            "product_type": rec["NOC_ENG_PRODUCT_TYPE"],
            "noc_with_conditions": rec["NOC_STATUS_WITH_CONDITIONS"],
            "therapeutic_class": rec["NOC_ENG_THERAPEUTIC_CLASS"],
            "reason_supplement": rec["NOC_ENG_REASON_SUPPLEMENT"],
            "reason_submission": rec["NOC_ENG_REASON_SUBMISSION"],
            "noc_url": f"https://health-products.canada.ca/noc-ac/info?lang=en&no={rec['NOC_NUMBER']}",
        })
    out_rows.sort(key=lambda x: (x["noc_date"], x["noc_number"]))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out_rows[0].keys()))
        w.writeheader()
        w.writerows(out_rows)
    print(f"SNDS in window: {n_snds}; matching /indication/i: {len(out_rows)} -> {a.out}")


if __name__ == "__main__":
    main()
