#!/usr/bin/env python3
"""Write PROVENANCE.json: checksums of every raw and output file, the source editions, and the software environment.

Run after run_all.sh. External researchers can compare their own rebuild against the shipped record with
    python scripts/provenance.py --check PROVENANCE.json
which reports every file whose SHA-256 differs (raw/ files should match exactly when the same snapshot is used;
interim/ and data/ files should match exactly when rebuilt from the same raw/ files).
"""
import argparse
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TRACKED_DIRS = ["raw", "interim", "data", "scripts", "tests", "review"]
PACKAGES = ["requests", "beautifulsoup4", "lxml", "pdfplumber", "pdfminer.six", "pypdfium2", "pandas", "pytest"]


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def file_records():
    out = {}
    for d in TRACKED_DIRS:
        for p in sorted((ROOT / d).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc" and p.name != "normalisation_provenance.json":
                rel = p.relative_to(ROOT).as_posix()
                out[rel] = {"sha256": sha256(p), "bytes": p.stat().st_size}
    return out


def environment():
    env = {"python": platform.python_version(), "platform": platform.platform(), "packages": {}}
    for pkg in PACKAGES:
        try:
            env["packages"][pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            env["packages"][pkg] = None
    try:
        env["poppler_pdftotext"] = subprocess.run(["pdftotext", "-v"], capture_output=True, text=True).stderr.strip().splitlines()[0]
    except Exception:  # noqa: BLE001
        env["poppler_pdftotext"] = None
    return env


def load_manifests():
    m = {}
    for p in sorted(ROOT.glob("raw/*/MANIFEST*.json")):
        m[p.relative_to(ROOT).as_posix()] = json.loads(p.read_text())
    for name in ("data/normalisation_provenance.json", "raw/normalisation/service_versions.json"):
        if (ROOT / name).exists():
            m[name] = json.loads((ROOT / name).read_text())
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", metavar="PROVENANCE.json", help="compare current files against a saved record")
    ap.add_argument("-o", "--out", default=str(ROOT / "PROVENANCE.json"))
    a = ap.parse_args()
    if a.check:
        ref = json.loads(Path(a.check).read_text())["files"]
        cur = file_records()
        changed = [k for k in ref if k in cur and cur[k]["sha256"] != ref[k]["sha256"]]
        missing = [k for k in ref if k not in cur]
        extra = [k for k in cur if k not in ref]
        for label, items in (("changed", changed), ("missing", missing), ("extra", extra)):
            print(f"{label}: {len(items)}")
            for k in items:
                print("  ", k)
        sys.exit(1 if changed or missing else 0)
    version_file = ROOT / "VERSION"
    rec = {
        "dataset_version": version_file.read_text().strip() if version_file.exists() else None,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "environment": environment(),
        "source_manifests": load_manifests(),
        "files": file_records(),
    }
    Path(a.out).write_text(json.dumps(rec, indent=1, sort_keys=True))
    print(f"{len(rec['files'])} files recorded -> {a.out}")


if __name__ == "__main__":
    main()
