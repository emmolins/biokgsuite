#!/usr/bin/env python3
"""Fetch TGA "extension of indications" (EOI) registrations from the Prescription medicines registrations search.

Listing: https://www.tga.gov.au/resources/prescription-medicines-registrations?f[0]=subtype:EOI&f[1]=published:<year>&page=<n>
  (facets: Registration type = EOI; Decision date year). 25 results per page.
Detail pages (one per registration) carry labelled fields in <div class="health-field"> blocks:
  Product name | Sponsor | Date registered | Evaluation commenced | Decision date | Approval time |
  Active ingredients | Registration type | Indication | (registration process flags: Priority review,
  Orphan drug, Provisional registration, ...)
The "Indication" field on an EOI page is the NEW indication text (TGA's own summary), which is what makes
this source unusually clean. Output: raw/tga/tga_eoi_items.json, one record per detail page, keyed by the
field labels as printed. tga_build.py turns it into the candidate CSV.

Usage:
    python scripts/fetch_tga.py --years 2023 2024 2025 2026 -o raw/tga/tga_eoi_items.json
"""
import argparse
import json
import re
from pathlib import Path

from bs4 import BeautifulSoup

from common import get, now_iso, session

BASE = "https://www.tga.gov.au"
LIST = BASE + "/resources/prescription-medicines-registrations?f%5B0%5D=subtype%3AEOI&f%5B1%5D=published%3A{}&page={}"


def parse_detail(html, url):
    soup = BeautifulSoup(html, "lxml")
    rec = {"url": url}
    for f in soup.select(".health-field"):
        lab = f.select_one(".field__label")
        it = f.select_one(".field__item")
        if not lab or not it:
            continue
        t = it.find("time")
        rec[lab.get_text(strip=True)] = t["datetime"] if t and t.get("datetime") else re.sub(r"[ \t]+\n", "\n", it.get_text("\n", strip=True))
    h1 = soup.find("h1")
    rec["title"] = h1.get_text(" ", strip=True) if h1 else ""
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--years", nargs="+", type=int, default=[2023, 2024, 2025, 2026])
    ap.add_argument("-o", "--out", default="raw/tga/tga_eoi_items.json")
    a = ap.parse_args()
    s = session()
    urls, listing = [], {}
    for y in a.years:
        for p in range(40):
            soup = BeautifulSoup(get(s, LIST.format(y, p)).text, "lxml")
            m = re.search(r"(\d+) result\(s\) found", soup.get_text(" ", strip=True))
            items = []
            for a_ in soup.find_all("a", href=True):
                h = a_["href"]
                if h.startswith("/resources/prescription-medicines-registrations/") and h not in items:
                    items.append(h)
            listing[f"{y}-{p}"] = {"count": m.group(1) if m else None, "n": len(items)}
            if not items:
                break
            for h in items:
                if h not in urls:
                    urls.append(h)
    print(f"{len(urls)} EOI registrations listed for {a.years}")
    recs, errors = [], []
    for i, h in enumerate(urls, 1):
        try:
            recs.append(parse_detail(get(s, BASE + h).text, BASE + h))
        except Exception as e:  # noqa: BLE001
            errors.append([h, str(e)])
        if i % 25 == 0:
            print(f"{i}/{len(urls)}")
    out = {"fetched_at": now_iso(), "listing": listing, "urls": urls, "items": recs, "errors": errors}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(f"{len(recs)} detail pages, {len(errors)} errors -> {a.out}")


if __name__ == "__main__":
    main()
