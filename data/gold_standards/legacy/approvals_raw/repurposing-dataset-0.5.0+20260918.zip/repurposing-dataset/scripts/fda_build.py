#!/usr/bin/env python3
"""FDA: build the candidate table of new-indication efficacy supplements (2023 to date).

Three sources are combined; each row keeps its provenance so the cleaning step can see
exactly which source said "New Indication".

1. openFDA Drugs@FDA endpoint (raw/fda/openfda_efficacy_supplements_2023plus.json, from fetch_openfda.py)
   Universe: every approved supplement (NDA and BLA, CDER) with submission_class_code == EFFICACY and
   an approval date >= 2023-01-01. This is the row set. openFDA does not carry the efficacy
   sub-type (SE1 new indication ... SE9), so it is joined to:
2. FDA "Efficacy Supplement Calendar Year Approvals" PDF reports (interim/fda_efficacy_supplements_pdf.csv,
   from fda_parse_efficacy_pdf.py): supplement type for every NDA and BLA efficacy supplement, published
   once per calendar year (2023, 2024, 2025 available; 2026 will appear in early 2027).
3. Drugs@FDA application pages (raw/fda/drugsatfda_supplement_categories.json, from fetch_drugsatfda.py):
   "Supplement Categories or Approval Type" per supplement, e.g. "Efficacy-New Indication". Available for
   NDAs only (Drugs@FDA shows BLA supplements as plain "Supplement"). This is the only sub-type source for
   2026 NDAs; for 2023 to 2025 it is a cross-check on the PDF.

Output columns: see FIELDS below. `is_new_indication_any` is True if either source labels the supplement
"New Indication"; rows where no source could classify the supplement (2026 BLAs) keep
supplement_type_pdf/drugsatfda empty so they can be classified from the approval letter later.
"""
import argparse
import csv
import json
import re
from collections import defaultdict
from datetime import datetime

FIELDS = [
    "regulator", "appl_type", "appl_no", "suppl_no", "approval_date", "review_priority",
    "brand_names", "active_ingredients", "sponsor", "unii", "rxcui",
    "supplement_type_pdf", "supplement_type_drugsatfda", "supplement_categories_drugsatfda",
    "is_new_indication_any", "subtype_source",
    "label_url", "letter_url", "review_url", "drugsatfda_url", "openfda_docs",
]


def norm_date(s):
    """openFDA: YYYYMMDD; PDF: M/D/YYYY; Drugs@FDA: MM/DD/YYYY -> ISO."""
    s = s.strip()
    for fmt in ("%Y%m%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError(s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--openfda", default="raw/fda/openfda_efficacy_supplements_2023plus.json")
    ap.add_argument("--pdf-csv", default="interim/fda_efficacy_supplements_pdf.csv")
    ap.add_argument("--drugsatfda", default="raw/fda/drugsatfda_supplement_categories.json")
    ap.add_argument("--start", default="2023-01-01")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()

    # --- source 2: PDF reports -> (appl_no, suppl_no) -> type (several rows possible: one per product name)
    pdf = defaultdict(set)
    pdf_names = defaultdict(set)
    with open(a.pdf_csv, newline="") as f:
        for r in csv.DictReader(f):
            key = (r["appl_no"], str(int(r["suppl_no"])))
            if r["supplement_type"]:
                pdf[key].add(r["supplement_type"])
            if r["established_name"] and r["established_name"] != "Data":
                pdf_names[key].add(r["established_name"])

    # --- source 3: Drugs@FDA application pages
    daf = {}
    with open(a.drugsatfda) as f:
        for r in json.load(f)["rows"]:
            m = re.match(r"SUPPL-(\d+)", r["submission"])
            if not m:
                continue
            key = (r["appl_no"], str(int(m.group(1))))
            daf[key] = r

    # --- source 1: openFDA universe
    with open(a.openfda) as f:
        ofda = json.load(f)
    out = []
    for app in ofda["results"]:
        appl_type, appl_no = app["application_number"][:3], app["application_number"][3:]
        brands = sorted({p["brand_name"] for p in app["products"] if p.get("brand_name")})
        ingredients = sorted({ai["name"] for p in app["products"] for ai in p.get("active_ingredients", [])})
        o = app.get("openfda") or {}
        for s in app["submissions"]:
            date = norm_date(s["submission_status_date"])
            if date < a.start:
                continue
            key = (appl_no, str(int(s["submission_number"])))
            docs = {d["type"]: d["url"] for d in s.get("application_docs", [])}
            d = daf.get(key)
            cats = d["category"] if d else ""
            eff_cats = [c.strip() for c in cats.split(",") if c.strip().startswith("Efficacy")] if cats else []
            daf_type = "; ".join(c.replace("Efficacy-", "") for c in eff_cats)
            pdf_type = "; ".join(sorted(pdf.get(key, [])))
            is_new = ("New Indication" in pdf_type) or ("New Indication" in daf_type)
            src = []
            if pdf_type:
                src.append("pdf")
            if daf_type:
                src.append("drugsatfda")
            daf_docs = {x["t"]: x["u"] for x in d["docs"]} if d else {}
            out.append({
                "regulator": "FDA",
                "appl_type": appl_type, "appl_no": appl_no, "suppl_no": key[1],
                "approval_date": date, "review_priority": s.get("review_priority", ""),
                "brand_names": "; ".join(brands) or "; ".join(sorted(pdf_names.get(key, []))),
                "active_ingredients": "; ".join(ingredients) or "; ".join(o.get("substance_name", []) or []),
                "sponsor": app.get("sponsor_name", ""),
                "unii": "; ".join(o.get("unii", []) or []), "rxcui": "; ".join(o.get("rxcui", []) or []),
                "supplement_type_pdf": pdf_type,
                "supplement_type_drugsatfda": daf_type,
                "supplement_categories_drugsatfda": cats,
                "is_new_indication_any": is_new,
                "subtype_source": "+".join(src) if src else "none",
                "label_url": docs.get("Label", daf_docs.get("Label (PDF)", "")),
                "letter_url": docs.get("Letter", daf_docs.get("Letter (PDF)", "")),
                "review_url": docs.get("Review", daf_docs.get("Review (PDF)", "")),
                "drugsatfda_url": f"https://www.accessdata.fda.gov/scripts/cder/daf/index.cfm?event=overview.process&ApplNo={appl_no}",
                "openfda_docs": json.dumps(docs),
            })
    out.sort(key=lambda r: (r["approval_date"], r["appl_no"], int(r["suppl_no"])))
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(out)
    n_new = sum(r["is_new_indication_any"] for r in out)
    n_none = sum(r["subtype_source"] == "none" for r in out)
    print(f"{len(out)} efficacy supplements; {n_new} labelled New Indication by >=1 source; {n_none} with no sub-type source -> {a.out}")


if __name__ == "__main__":
    main()
