#!/usr/bin/env python3
"""TGA: candidate table from the EOI detail records fetched by fetch_tga.py.

Every EOI (extension of indications) registration is kept; the cleaning step decides whether the new
indication is a different disease (repurposing) or a population/line extension. Flags for the special
registration pathways (Orphan drug, Priority review, Provisional registration) are carried through.

Usage:
    python scripts/tga_build.py --items raw/tga/tga_eoi_items.json --start 2023-01-01 -o interim/tga_candidates.csv
"""
import argparse
import csv
import json
import re

FIELDS = ["regulator", "decision_date", "date_registered", "evaluation_commenced", "product_name", "sponsor",
          "active_ingredients", "registration_type", "indication_text", "orphan", "priority_review",
          "provisional", "approval_time", "url"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--items", default="raw/tga/tga_eoi_items.json")
    ap.add_argument("--start", default="2023-01-01")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    d = json.load(open(a.items, encoding="utf-8"))
    rows = []
    for it in d["items"]:
        dec = (it.get("Decision date") or "")[:10]
        if dec < a.start:
            continue
        rows.append({
            "regulator": "TGA",
            "decision_date": dec,
            "date_registered": (it.get("Date registered") or "")[:10],
            "evaluation_commenced": (it.get("Evaluation commenced") or "")[:10],
            "product_name": it.get("Product name", ""),
            "sponsor": it.get("Sponsor", ""),
            "active_ingredients": it.get("Active ingredients", ""),
            "registration_type": it.get("Registration type", ""),
            "indication_text": re.sub(r"\n{2,}", "\n", it.get("Indication", "")).strip(),
            "orphan": "Orphan drug" in it,
            "priority_review": "Priority review" in it,
            "provisional": "Provisional registration" in it,
            "approval_time": it.get("Approval time", ""),
            "url": it["url"],
        })
    rows.sort(key=lambda r: (r["decision_date"], r["product_name"]))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} TGA EOI registrations -> {a.out}")


if __name__ == "__main__":
    main()
