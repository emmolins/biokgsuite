#!/usr/bin/env python3
"""PMDA (Japan): candidate new-indication approvals from the English "List of Approved Drugs" PDF.

Source: https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html
  -> "New Drugs" PDF (currently https://www.pmda.go.jp/files/000281190.pdf, "April 2004 to February 2026",
     re-issued as approvals accumulate; the file number may change, so fetch_pmda.py resolves it from the page).
The PDF is one ruled table per page: Review Category | Approval Date | No. | Brand Name (Applicant) |
New Approval / Partial Change | Active Ingredient | Notes. It is in reverse chronological order (most
recent first); fiscal-year sections (FY = April to March) and, for the latest months, monthly sections.

Japan classifies applications rather than supplements. The Notes column carries the classification text:
  "A drug with a new active ingredient ..."  (new active ingredient; NOT repurposing)
  "A drug with a new indication ..."          (= FDA "new indication" efficacy supplement; usually a
                                               "Change" = partial change approval of an existing product)
  "... new dosage ...", "... additional pediatric dosage ...", "new dosage form", "new route", etc.
This script keeps every row in the date window whose Notes mention a new indication (regex NEW_IND_RE),
including rows that combine a new indication with a new dosage/dosage form, and records the full Notes
text plus flags so the cleaning step can separate pure new-indication approvals from combinations.

Usage:
    python scripts/pmda_parse_approved_list.py raw/pmda/<file>.pdf --start 2023-01-01 -o interim/pmda_candidates.csv
"""
import argparse
import csv
import re
import sys
from datetime import date, datetime

import pdfplumber

NEW_IND_RE = re.compile(r"\bnew\s+indications?\b", re.I)
NEW_AI_RE = re.compile(r"new\s+active\s+ingredient", re.I)
DATE_FORMATS = ["%b. %d, %Y", "%B %d, %Y", "%b %d, %Y", "%d-%b-%y"]
FIELDS = ["regulator", "approval_date", "fy_or_month_section", "review_category", "row_no", "brand_names",
          "applicant", "approval_or_change", "active_ingredients", "notes", "mentions_new_indication",
          "mentions_new_active_ingredient", "orphan", "page", "source_pdf"]


def parse_date(s):
    s = re.sub(r"\s+", " ", s.strip())
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"unrecognised date {s!r}")


def split_brand(cell):
    """The Brand Name cell lists product names, then the applicant in parentheses on the last line(s)."""
    lines = [l.strip() for l in cell.split("\n") if l.strip()]
    brands, applicant = [], []
    in_applicant = False
    for l in lines:
        # "(Novartis Pharma K.K.)" or "((1) Novartis ... (2) Nippon ...)" opens the applicant block;
        # "(1) Skyrizi ..." is a numbered product line, not the applicant
        if not in_applicant and l.startswith("(") and not re.match(r"^\(\d+\)\s*[^\s(]", l):
            in_applicant = True
        if in_applicant:
            applicant.append(l)
        else:
            brands.append(l)
    app = " ".join(applicant).strip()
    if app.startswith("(") and app.endswith(")"):
        app = app[1:-1]
    return brands, app


def parse_pdf(path, start, end):
    rows = []
    section = ""
    with pdfplumber.open(path) as pdf:
        for pno, page in enumerate(pdf.pages, start=1):
            txt = page.extract_text() or ""
            m = re.search(r"New Drugs Approved in (.+)", txt)
            if m:
                section = m.group(1).strip()
            for tbl in page.extract_tables():
                for r in tbl:
                    if not r or len(r) < 7 or not r[1]:
                        continue
                    cat, dt, no, brand, chg, ai, notes = [(c or "").strip() for c in r[:7]]
                    if cat.startswith("Review") or dt.startswith("Approval"):
                        continue  # header row
                    try:
                        d = parse_date(dt)
                    except ValueError:
                        continue
                    if not (start <= d <= end):
                        continue
                    brands, applicant = split_brand(brand)
                    notes_1 = re.sub(r"\s*\n\s*", " ", notes)
                    rows.append({
                        "regulator": "PMDA",
                        "approval_date": d.isoformat(),
                        "fy_or_month_section": section,
                        "review_category": re.sub(r"\s+", " ", cat),
                        "row_no": no,
                        "brand_names": "; ".join(brands),
                        "applicant": applicant,
                        "approval_or_change": "; ".join(x for x in chg.split("\n") if x),
                        "active_ingredients": re.sub(r"\s*\n\s*", " ", ai),
                        "notes": notes_1,
                        "mentions_new_indication": bool(NEW_IND_RE.search(notes_1)),
                        "mentions_new_active_ingredient": bool(NEW_AI_RE.search(notes_1)),
                        "orphan": "[Orphan drug]" in notes_1,
                        "page": pno,
                        "source_pdf": path.split("/")[-1],
                    })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--start", default="2023-01-01")
    ap.add_argument("--end", default=date.today().isoformat())
    ap.add_argument("--all-rows", action="store_true", help="keep every row in the window, not only new-indication ones")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    rows = parse_pdf(a.pdf, date.fromisoformat(a.start), date.fromisoformat(a.end))
    n_all = len(rows)
    if not a.all_rows:
        rows = [r for r in rows if r["mentions_new_indication"]]
    rows.sort(key=lambda r: (r["approval_date"], r["page"], int(r["row_no"]) if r["row_no"].isdigit() else 0))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(f"{n_all} approvals in window; {len(rows)} written -> {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
