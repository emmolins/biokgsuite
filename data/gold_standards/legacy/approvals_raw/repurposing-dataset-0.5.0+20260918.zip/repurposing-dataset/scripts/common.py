"""Shared helpers for the fetch scripts: a polite HTTP session with retries and on-disk caching notes."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

UA = "repurposing-dataset/0.1 (academic research; contact: see README)"


def session():
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Accept-Language": "en"})
    return s


def get(s, url, retries=4, sleep=0.5, **kw):
    """GET with simple exponential back-off. Drugs@FDA returns 403 when hit too fast; EMA/TGA are fine at ~2 req/s."""
    last = None
    for attempt in range(retries):
        r = s.get(url, timeout=60, **kw)
        if r.status_code == 200:
            time.sleep(sleep)
            return r
        last = r
        time.sleep(sleep * (2 ** (attempt + 1)))
    raise RuntimeError(f"GET {url} failed: HTTP {last.status_code if last else '?'}")


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_manifest(path, **fields):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps({"fetched_at": now_iso(), **fields}, indent=1))
