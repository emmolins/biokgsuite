#!/usr/bin/env python3
"""Apply the review decisions in review/ to data/candidates_normalised.csv -> data/candidates_reviewed.csv.

Inputs
  data/candidates_normalised.csv      pipeline output (scripts/normalise.py)
  review/review_decisions.csv         one decision per (candidate_id, field); fields:
        repurposing_class  new_indication | expanded_population | line_extension | wording_only | unclear |
                           commitment_fulfilment | indication_removed | formulation_or_route | out_of_scope_veterinary |
                           biosimilar_alignment (a biosimilar adding an indication its reference product already holds) |
                           ingredient_prior_indication (new for the product, but the active ingredient already held the
                           indication in another product or the pair was approved before 2023 elsewhere) |
                           first_indication (first approval of a new active substance)
                           Classes are judged for the active ingredient, not the product: new_indication = a disease no
                           product with the ingredient held before (a different MONDO branch); line_extension = the same
                           disease or a subtype, stage, line, regimen or prevention setting of a disease already held
        disease            MONDO:nnnnnnn                      a MONDO id chosen by the reviewer
                           lookup:<label>                     resolve the label (pins -> MONDO label index -> Name Resolver)
                           lookup:text                        indication not stated in the source row; needs label/EPAR text
                           multi:<decision>;<decision>        several diseases on one approval (each part as above)
                           not_disease:<reason>               no disease entity (diagnostic, procedural, cosmetic ...)
        drug               <CURIE>                            an identifier chosen by the reviewer
                           lookup:<name>[;prefix=<PREFIX>]    resolve by name with Name Resolver (optionally prefer a prefix)
                           vaccine:<label>[;id=<CURIE>]       product-level vaccine (drug_class=vaccine); resolved by name unless an id is given
                           multi:<decision>;<decision>        fixed-dose combination; one identifier per component
                           unresolved:<reason>                cannot be mapped; row leaves scope
  review/disease_label_pins.csv       reviewer-chosen MONDO ids for labels whose MONDO name differs (synonym/parent)
  raw/normalisation/mondo.sssom.tsv   MONDO labels (same file normalise.py uses)
  raw/normalisation/cache.json        cached Translator responses; new lookups are added here (or listed with --plan)

Outputs
  data/candidates_reviewed.csv        all rows, with repurposing_class, in_scope, final drug/disease identifiers and status
  data/review_pending.csv             rows whose drug or disease is still unresolved, with what is needed

Resolution order for `lookup:<label>` diseases: review/disease_label_pins.csv, then an exact (case-insensitive) match
on the MONDO label index, then the cached/live Name Resolver top hit restricted to MONDO. Every live call is cached, so
`--offline` reproduces the shipped file exactly; `--plan requests.json` lists the calls a live run would make.

Usage
    python scripts/apply_review.py                # live for anything not cached
    python scripts/apply_review.py --offline      # cache only (reproducible)
    python scripts/apply_review.py --plan req.json
"""
import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from normalise import (CACHE_PATH, DISEASE_TYPES, DRUG_PREFIXES, DRUG_TYPES, SSSOM_PATH, Cache, equivalents,  # noqa: E402
                       load_sssom, name_lookup, normalize_curie)

ROOT = Path(__file__).resolve().parents[1]
OUT_OF_SCOPE_CLASSES = {"out_of_scope_veterinary", "indication_removed", "wording_only", "line_extension",
                        "formulation_or_route", "commitment_fulfilment", "biosimilar_alignment",
                        "ingredient_prior_indication", "first_indication"}
# not_disease reasons that mean the approval has no disease target for a drug-disease KG
NO_TARGET = {"diagnostic", "procedural", "cosmetic", "contraception", "disinfectant", "surgical", "conditioning", "symptom",
             "veterinary"}


def load_decisions(path):
    dec = {}
    for r in csv.DictReader(open(path, newline="", encoding="utf-8")):
        dec[(r["candidate_id"], r["field"])] = r
    return dec


def load_pins(path):
    pins = {}
    if path.exists():
        for r in csv.DictReader(open(path, newline="", encoding="utf-8")):
            pins[r["label"].lower()] = (r["mondo_id"], r["mondo_label"], r.get("note", ""))
    return pins


def resolve_disease_part(part, pins, label_index, cache):
    """-> (mondo_id, mondo_label, status, note)"""
    part = part.strip()
    if part.startswith("MONDO:"):
        return part, label_index.get(part, ""), "reviewed_id", ""
    if part == "lookup:text":
        return "", "", "pending_source_text", "indication not stated in the source row"
    if part.startswith("lookup:"):
        label = part[7:].strip()
        if label.lower() in pins:
            mid, mlabel, note = pins[label.lower()]
            return mid, mlabel, "reviewed_label_pinned", note
        hits = [k for k, v in label_index.items() if v.lower() == label.lower()]
        if hits:
            return hits[0], label_index[hits[0]], "reviewed_label_exact", ""
        resp = name_lookup(cache, label, DISEASE_TYPES)
        if isinstance(resp, list):
            mondo = [h for h in resp if h.get("curie", "").startswith("MONDO:")]
            if mondo:
                top = mondo[0]
                return top["curie"], top.get("label", ""), "reviewed_label_resolver", f"Name Resolver top MONDO hit for '{label}' (score {top.get('score', 0):.1f})"
            return "", "", "pending_lookup", f"no MONDO hit for '{label}'"
        return "", "", "pending_lookup", f"Name Resolver call needed for '{label}'"
    if part.startswith("not_disease:"):
        return "", "", "not_disease", part[12:]
    return "", "", "pending_lookup", f"unrecognised decision '{part}'"


def resolve_disease(decision, pins, label_index, cache):
    parts = decision[6:].split(";") if decision.startswith("multi:") else [decision]
    ids, labels, statuses, notes = [], [], [], []
    for p in parts:
        mid, mlabel, status, note = resolve_disease_part(p, pins, label_index, cache)
        if mid:
            ids.append(mid)
            labels.append(mlabel)
        statuses.append(status)
        if note:
            notes.append(note)
    if any(s.startswith("pending") for s in statuses):
        status = "pending_source_text" if "pending_source_text" in statuses else "pending_lookup"
    elif all(s == "not_disease" for s in statuses):
        status = "not_disease"
    else:
        status = "reviewed_multi" if len(parts) > 1 else statuses[0]
    return "; ".join(ids), "; ".join(labels), status, "; ".join(notes)


def pick_curie(resp, prefer=None):
    if not isinstance(resp, list) or not resp:
        return None
    if prefer:
        for h in resp:
            if h.get("curie", "").startswith(prefer + ":"):
                return h
    return resp[0]


def drug_ids_from_curie(curie, cache):
    """CURIE -> (preferred id, label, DrugBank id) using the Node Normalizer clique (conflated)."""
    eq, label = equivalents(normalize_curie(cache, curie), curie)
    if not eq:
        return curie, "", ""
    for p in DRUG_PREFIXES:
        if eq.get(p):
            preferred = f"{p}:{eq[p][0]}"  # equivalents() returns local ids without prefix
            break
    else:
        preferred = curie
    return preferred, label, (eq.get("DRUGBANK") or [""])[0]


def resolve_drug_part(part, cache):
    """-> (id, label, drugbank, drug_class, status, note)"""
    part = part.strip()
    if part.startswith("unresolved:"):
        return "", "", "", "", "unresolved", part[11:]
    if part.startswith("vaccine:"):
        label, _, opt = part[8:].strip().partition(";")
        if opt.startswith("id="):  # reviewer-chosen product-level identifier
            return opt[3:], label, "", "vaccine", "reviewed_vaccine_id", f"product-level: {label}"
        resp = name_lookup(cache, label.split(" (")[0].strip(), DRUG_TYPES)  # brand/site in parentheses is not sent
        hit = pick_curie(resp)
        if hit:
            return hit["curie"], hit.get("label", ""), "", "vaccine", "reviewed_vaccine_resolver", f"product-level: {label}"
        return "", label, "", "vaccine", "pending_lookup" if resp is None else "vaccine_unmapped", f"product-level: {label}"
    if part.startswith("lookup:"):
        body = part[7:]
        name, _, opt = body.partition(";")
        prefer = opt.split("=", 1)[1] if opt.startswith("prefix=") else None
        resp = name_lookup(cache, name.strip(), DRUG_TYPES)
        hit = pick_curie(resp, prefer)
        if hit:
            pid, label, db = drug_ids_from_curie(hit["curie"], cache)
            return pid, label or hit.get("label", ""), db, "", "reviewed_lookup", f"resolved '{name.strip()}' -> {hit['curie']}"
        return "", "", "", "", "pending_lookup", f"Name Resolver call needed for '{name.strip()}'" if resp is None else f"no hit for '{name.strip()}'"
    if ":" in part:  # a CURIE
        pid, label, db = drug_ids_from_curie(part, cache)
        return pid, label, db, "", "reviewed_id", f"reviewer chose {part}"
    return "", "", "", "", "pending_lookup", f"unrecognised decision '{part}'"


def resolve_drug(decision, cache):
    parts = decision[6:].split(";") if decision.startswith("multi:") else [decision]
    ids, labels, dbs, classes, statuses, notes = [], [], [], [], [], []
    for p in parts:
        pid, label, db, cls, status, note = resolve_drug_part(p, cache)
        if pid:
            ids.append(pid)
            labels.append(label)
        if db:
            dbs.append(db)
        if cls:
            classes.append(cls)
        statuses.append(status)
        if note:
            notes.append(note)
    if "unresolved" in statuses:
        status = "unresolved"
    elif any(s == "pending_lookup" for s in statuses):
        status = "pending_lookup"
    else:
        status = "reviewed_multi" if len(parts) > 1 else statuses[0]
    return "; ".join(ids), "; ".join(labels), "; ".join(dbs), "; ".join(sorted(set(classes))), status, "; ".join(notes)


def pipeline_drug_id(row):
    for p in DRUG_PREFIXES:
        v = row.get("drug_" + p.lower().replace(".", "_"), "")
        if v:
            v = v.split(";")[0].strip()
            return v if ":" in v else f"{p}:{v}"  # pipeline columns hold bare local ids
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", default="data/candidates_normalised.csv")
    ap.add_argument("--decisions", default="review/review_decisions.csv")
    ap.add_argument("--pins", default="review/disease_label_pins.csv")
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--plan", metavar="FILE")
    ap.add_argument("-o", "--out", default="data/candidates_reviewed.csv")
    ap.add_argument("--pending", default="data/review_pending.csv")
    a = ap.parse_args()

    cache = Cache(CACHE_PATH, a.offline, plan=bool(a.plan))
    _, label_index = load_sssom(SSSOM_PATH)
    pins = load_pins(Path(a.pins))
    decisions = load_decisions(a.decisions)
    rows = list(csv.DictReader(open(a.candidates, newline="", encoding="utf-8")))

    out, pending = [], []
    for r in rows:
        cid = r["candidate_id"]
        o = dict(r)
        # 1. repurposing class
        d = decisions.get((cid, "repurposing_class"))
        flag = r["classification_flag"]
        if d:
            o["repurposing_class"], o["class_source"], o["class_rationale"] = d["decision"], "review", d["rationale"]
        elif flag == "new_indication":
            o["repurposing_class"], o["class_source"], o["class_rationale"] = "new_indication", "pipeline", r["classification_source"]
        elif flag == "text_match":
            o["repurposing_class"], o["class_source"], o["class_rationale"] = "unclear", "pipeline", "text match only, not reviewed"
        elif flag.startswith("excluded"):
            o["repurposing_class"], o["class_source"], o["class_rationale"] = "excluded", "pipeline", flag
        else:
            o["repurposing_class"], o["class_source"], o["class_rationale"] = "unclassified", "pipeline", flag
        # 2. disease
        d = decisions.get((cid, "disease"))
        if d:
            o["disease_decision"] = d["decision"]
            mid, mlabel, status, note = resolve_disease(d["decision"], pins, label_index, cache)
            o["mondo_id_final"], o["mondo_label_final"], o["disease_status"], o["disease_note"] = mid, mlabel, status, (d["rationale"] + ("; " + note if note else ""))
        elif r["mondo_id"] and not any(x.strip().startswith(("disease", "no MONDO", "could not")) for x in r["review_reason"].split("|")):
            o["disease_decision"], o["mondo_id_final"], o["mondo_label_final"], o["disease_status"], o["disease_note"] = "", r["mondo_id"], r["mondo_label"], "pipeline", "accepted pipeline match"
        elif not r["indication_text"]:
            o["disease_decision"], o["mondo_id_final"], o["mondo_label_final"], o["disease_status"], o["disease_note"] = "", "", "", "pending_source_text", "no indication text in source row (label/EPAR needed)"
        else:
            o["disease_decision"], o["mondo_id_final"], o["mondo_label_final"], o["disease_status"], o["disease_note"] = "", "", "", "pending_lookup", "flagged by pipeline, no decision recorded"
        # 3. drug
        d = decisions.get((cid, "drug"))
        if d:
            o["drug_decision"] = d["decision"]
            pid, label, db, cls, status, note = resolve_drug(d["decision"], cache)
            o["drug_id_final"], o["drug_label_final"], o["drug_drugbank_final"], o["drug_class"], o["drug_status"] = pid, label, (db or r["drug_drugbank"]).replace("DRUGBANK:", ""), cls, status
            o["drug_note"] = d["rationale"] + ("; " + note if note else "")
        else:
            pid = pipeline_drug_id(r)
            o["drug_decision"], o["drug_id_final"], o["drug_label_final"], o["drug_drugbank_final"], o["drug_class"] = "", pid, r["drug_label"], r["drug_drugbank"], ""
            o["drug_status"], o["drug_note"] = ("pipeline" if pid else "unresolved"), ("accepted pipeline match" if pid else "pipeline found no identifier")
        # 4. scope
        reasons = []
        if o["repurposing_class"] in OUT_OF_SCOPE_CLASSES or o["repurposing_class"] == "excluded":
            reasons.append(f"class={o['repurposing_class']}")
        if o["disease_status"] == "not_disease":
            reasons.append("no disease target")
        if o["drug_status"] == "unresolved" and o["drug_decision"].startswith("unresolved:"):
            reasons.append("drug " + o["drug_decision"])
        o["in_scope"] = not reasons
        o["exclusion_reason"] = "; ".join(reasons)
        o["kg_ready"] = bool(o["in_scope"] and o["mondo_id_final"] and o["drug_id_final"] and o["repurposing_class"] == "new_indication")
        out.append(o)
        if o["in_scope"] and (o["disease_status"].startswith("pending") or o["drug_status"] in ("pending_lookup", "unresolved", "vaccine_unmapped")):
            pending.append({k: o[k] for k in ("candidate_id", "regulator", "event_date", "product_name", "active_ingredient",
                                              "repurposing_class", "disease_status", "disease_decision", "disease_note",
                                              "drug_status", "drug_decision", "drug_note", "document_url", "source_url")})
    if a.plan:
        Path(a.plan).write_text(json.dumps([{"key": k, **(v or {})} for k, v in cache.missing.items()], indent=0))
        print(f"{len(cache.missing)} API requests not in cache -> {a.plan}", file=sys.stderr)
        return
    cache.save()
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    with open(a.pending, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(pending[0].keys()) if pending else ["candidate_id"])
        w.writeheader()
        w.writerows(pending)
    cls = Counter(o["repurposing_class"] for o in out)
    print(f"{len(out)} rows -> {a.out}; classes {dict(cls)}", file=sys.stderr)
    print(f"in scope {sum(o['in_scope'] for o in out)}; kg_ready {sum(o['kg_ready'] for o in out)}; "
          f"disease status {dict(Counter(o['disease_status'] for o in out))}; drug status {dict(Counter(o['drug_status'] for o in out))}",
          file=sys.stderr)
    print(f"{len(pending)} in-scope rows still pending -> {a.pending}", file=sys.stderr)


if __name__ == "__main__":
    main()
