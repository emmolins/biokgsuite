#!/usr/bin/env python3
"""Match each CHMP extension-of-indication opinion to the entry in the medicine's EPAR
"Procedural steps taken and scientific information after the authorisation" PDF (current + archive), which
records, per variation, the scope ("Extension of indication to include ..."), the opinion date and the
Commission decision date.

Inputs
  interim/ema_candidates.csv                                    one row per CHMP highlights card
  raw/ema/procedural_steps/indication_windows.json              text windows around "indication" in the current PDF
  raw/ema/procedural_steps/indication_windows_archive.json      same for the archive PDF
  (both written from the browser: pdf.js text of every page, windows of 900/700 or 500/1100 characters around
   each match, only windows carrying a 2022-2026 date kept for the archive)

Matching rule
  For a card with meeting end date D, the variation entries are the "Extension of indication" (or C.I.6 change to
  therapeutic indication) scopes whose opinion date is within MAX_DAYS (12) of D. The opinion date is the first
  dd/mm/yyyy after the scope text (the table column order is Scope, Opinion date, Decision date). When several
  entries qualify (two variations adopted at one meeting; worksharing procedures listing Opdivo and Yervoy scopes
  together) all are kept, joined with " || ", the one naming the medicine first.

Output
  interim/ema_procedural_indications.csv  candidate_id, source_row_id, slug, matched, source, scope_text, opinion_date,
                                          decision_date, procedure_no, doc_url
"""
import argparse
import csv
import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

MAX_DAYS = 12
MONTHS = {m: i for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july", "august",
                                      "september", "october", "november", "december"], 1)}
DATE_RE = re.compile(r"\b(\d{2})/(\d{2})/(20\d{2})\b")
SCOPE_RE = re.compile(r"(Extension of (?:the )?indication[^.]*?(?:\.|(?=\s{2,}\d{2}/\d{2}/20\d{2})))|"
                      r"((?:Addition of a )?new (?:therapeutic )?indication[^.]*?\.)", re.I | re.S)
PROC_RE = re.compile(r"\b((?:II|X|WS|IB|IA|IAIN|IG)/\d{3,4}(?:/G)?|EMA/VR/\d+|WS/\d+)\b")


def meeting_end(meeting: str):
    """'23-26 January 2023' -> date(2023, 1, 26); '30 January-2 February 2023' -> date(2023, 2, 2)."""
    m = re.search(r"(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})\s*$", meeting.strip())
    if not m:
        return None
    return date(int(m.group(3)), MONTHS[m.group(2).lower()], int(m.group(1)))


def slug_for(row):
    s = row["epar_url"].rstrip("/").split("/")[-1]
    if s.isdigit() or s.endswith(".pdf") or not s:
        s = re.sub(r"[^a-z0-9]+", "-", row["medicine"].lower()).strip("-")
    return s


ALT = {"bimervax-0": "bimervax", "keytruda-0": "keytruda", "keytruda-1": "keytruda", "rinvoq-1": "rinvoq",
       "tecentriq-2": "tecentriq", "veraseal-0": "veraseal",
       "onivyde-pegylated-liposomal-previously-known-onivyde": "onivyde-pegylated-liposomal"}


def entries(text: str):
    """Yield (scope_text, opinion_date, decision_date, procedure_no) for every indication change in a window."""
    for m in SCOPE_RE.finditer(text):
        scope = re.sub(r"\s+", " ", m.group(0)).strip()
        tail = text[m.end(): m.end() + 1800]
        dates = DATE_RE.findall(tail)
        if not dates:
            head = text[max(0, m.start() - 400): m.start()]
            dates = DATE_RE.findall(head)[-2:]
        if not dates:
            continue
        op = _d(dates[0])
        dec = _d(dates[1]) if len(dates) > 1 and (_d(dates[1]) - op).days in range(0, 400) else None
        proc = PROC_RE.findall(text[max(0, m.start() - 250): m.start()])
        yield scope[:1200], op, dec, (proc[-1] if proc else "")


def _d(t):
    return date(int(t[2]), int(t[1]), int(t[0]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", default="interim/ema_candidates.csv")
    ap.add_argument("--windows", default="raw/ema/procedural_steps/indication_windows.json")
    ap.add_argument("--archive", default="raw/ema/procedural_steps/indication_windows_archive.json")
    ap.add_argument("-o", "--out", default="interim/ema_procedural_indications.csv")
    a = ap.parse_args()
    cur = json.loads(Path(a.windows).read_text())
    arc = json.loads(Path(a.archive).read_text()) if Path(a.archive).exists() else {}
    out = []
    for r in csv.DictReader(open(a.candidates, newline="", encoding="utf-8")):
        slug = slug_for(r)
        cid = f"EMA:{r['meeting_url'].rsplit('chmp-', 1)[-1]}:{re.sub(r'[^A-Za-z0-9]+', '-', r['medicine']).strip('-')}"
        srid = f"{r['source_file']}:{r['medicine']}"
        end = meeting_end(r["meeting"])
        best, src = None, ""
        for source, store in (("current", cur), ("archive", arc)):
            rec = store.get(slug) or store.get(ALT.get(slug, ""))
            if not rec or rec.get("status") != 200:
                continue
            cands = []
            for w in rec.get("wins", []):
                for scope, op, dec, proc in entries(w):
                    if end and abs((op - end).days) <= MAX_DAYS:
                        cands.append((scope, op, dec, proc))
            if cands:
                # one CHMP meeting can adopt several indication variations for one medicine (Tevimbra, October
                # 2024: gastric/GEJ and first-line OSCC); keep every qualifying scope, the one naming the
                # medicine first, so the review sees the whole opinion
                named = [c for c in cands if r["medicine"].split()[0].lower() in c[0].lower()]
                ordered, seen = [], set()
                for c in named + cands:
                    if c[0] not in seen:
                        ordered.append(c)
                        seen.add(c[0])
                best = (" || ".join(c[0] for c in ordered), min(c[1] for c in ordered),
                        next((c[2] for c in ordered if c[2]), None), ";".join(sorted({c[3] for c in ordered if c[3]})))
                src = source
                break
        doc = (f"https://www.ema.europa.eu/en/documents/procedural-steps-after/{ALT.get(slug, slug)}-epar-procedural-steps-"
               f"taken-scientific-information-after-authorisation{'-archive' if src == 'archive' else ''}_en.pdf")
        out.append(dict(candidate_id=cid, source_row_id=srid, slug=slug, matched=bool(best), source=src,
                        scope_text=best[0] if best else "", opinion_date=best[1].isoformat() if best else "",
                        decision_date=best[2].isoformat() if best and best[2] else "",
                        procedure_no=best[3] if best else "", doc_url=doc if best else ""))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    n = sum(1 for o in out if o["matched"])
    n_scope = sum(1 for o in out if o["matched"] and re.search(r"to include|new indication", o["scope_text"], re.I))
    print(f"{len(out)} CHMP cards: {n} matched to a procedural-steps entry ({n_scope} with scope wording); "
          f"{len(out) - n} unmatched -> {a.out}")


if __name__ == "__main__":
    main()
