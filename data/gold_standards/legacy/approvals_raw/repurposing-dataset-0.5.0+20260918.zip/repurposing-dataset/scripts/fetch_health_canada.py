#!/usr/bin/env python3
"""Download the Health Canada Notice of Compliance (NOC) data extract files (updated weekly).

Page:   https://www.canada.ca/en/health-canada/services/drugs-health-products/drug-products/notice-compliance/database/data-extract.html
Readme: https://www.canada.ca/en/health-canada/services/drugs-health-products/drug-products/notice-compliance/database/read-file.html
Files are comma-delimited, double-quoted, no header row; field order is documented in the readme and in
health_canada_extract.py (MAIN_FIELDS). Licence: Open Government Licence - Canada.

Usage:
    python scripts/fetch_health_canada.py -o raw/health_canada
"""
import argparse
from pathlib import Path

from common import get, session, write_manifest

BASE = "https://www.canada.ca/content/dam/hc-sc/documents/services/drugs-health-products/drug-products/notice-compliance/database/"
FILES = ["noc_main.txt", "noc_brand.txt", "noc_din_product.txt", "noc_product_ingredient.txt"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default="raw/health_canada")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    s = session()
    meta = {}
    for f in FILES:
        r = get(s, BASE + f)
        (out / f).write_bytes(r.content)
        meta[f] = {"bytes": len(r.content), "last_modified": r.headers.get("Last-Modified", "")}
        print(f, meta[f])
    write_manifest(out / "MANIFEST.json", base=BASE, files=meta)


if __name__ == "__main__":
    main()
