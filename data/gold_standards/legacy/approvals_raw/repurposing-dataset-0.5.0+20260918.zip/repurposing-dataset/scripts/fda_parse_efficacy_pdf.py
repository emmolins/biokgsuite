#!/usr/bin/env python3
"""Parse the FDA calendar-year efficacy supplement approval reports into a CSV.

Source: https://www.fda.gov/drugs/nda-and-bla-approvals/efficacy-supplement-approvals
Each report is a fixed-column PDF listing every NDA/BLA efficacy supplement approved
by CDER in that calendar year, with its SUPPLEMENT TYPE (New Indication, New Patient
Population, New Dosing Regimen, Labeling Change With Clinical Data, ...).

Usage:
    python scripts/fda_parse_efficacy_pdf.py raw/fda/efficacy_supplements_CY2023.pdf [...] -o out.csv

Parsing strategy (robust to the small layout changes between years):
  * The report has three sections (NDA, "NDA ... (SE8)" i.e. labeling changes with
    clinical data, and BLA), each introduced by its own column-header row.
  * Every cell is left-aligned, so within a section the seven most frequent word x0
    values are the column left edges; words are assigned to columns by those edges.
  * Words are clustered into lines by their vertical position. A line starting with
    "NDA nnnnnn" / "BLA nnnnnn" is a record anchor; other lines are wrapped halves of
    a cell. The report prints the first half of a wrapped cell ABOVE the anchor line
    (also across page breaks), so pending lines are glued to the next anchor.
"""
import argparse
import csv
import re
import sys
from pathlib import Path

import pdfplumber

ANCHOR_RE = re.compile(r"^(NDA|BLA)\s+(\d{6})(?:\s*\((\d+)\))?$")
HEADER_KEYS = ["APPL NUMBER", "NUMBER", "SUBMISSION CLASS CODE", "ESTABLISHED NAME", "APPLICANT", "REVIEW", "DATE"]
COLS = ["appl", "suppl_no", "supplement_type", "established_name", "applicant", "priority", "approval_date"]


def cluster_lines(words, tol=3.0):
    words = sorted(words, key=lambda w: (round(w["top"]), w["x0"]))
    lines = []
    for w in words:
        if lines and abs(lines[-1]["top"] - w["top"]) <= tol:
            lines[-1]["words"].append(w)
        else:
            lines.append({"top": w["top"], "words": [w]})
    for ln in lines:
        ln["words"].sort(key=lambda w: w["x0"])
    return lines


HEADER_ALIASES = {
    "APPL NUMBER": 0, "NUMBER": 1,
    "SUBMISSION CLASS CODE": 2, "SUPPLEMENT TYPE": 2,
    "ESTABLISHED NAME": 3, "PROPER NAME": 3,
    "APPLICANT": 4, "REVIEW": 5, "DATE": 6,
}
SECTION_RE = re.compile(r"^(NDA|BLA) Efficacy Supplements Approved")


def is_header_line(ln):
    keys = {HEADER_ALIASES.get(w["text"].strip()) for w in ln["words"]}
    keys.discard(None)
    return len(keys) >= 5


def column_starts(lines):
    """Derive the 7 left edges of the columns from the data itself.

    Every cell in the report is left-aligned, so each column's x0 is repeated on
    (almost) every row; the seven most frequent x0 values, in order, are the columns.
    """
    from collections import Counter
    c = Counter()
    for ln in lines:
        for w in ln["words"]:
            c[round(w["x0"])] += 1
    # merge x0 values that are within 4pt of a more frequent value
    starts = []
    for x, n in c.most_common():
        if any(abs(x - s) <= 4 for s, _ in starts):
            continue
        starts.append((x, n))
    starts = sorted(starts[:7])
    if len(starts) != 7:
        raise ValueError(f"expected 7 column starts, got {starts}")
    return [x for x, _ in starts]


CANONICAL_TYPES = [
    "New Indication", "New Patient Population", "New Dosing Regimen", "New Route Of Administration",
    "Labeling Change With Clinical Data", "Manufacturing Change With Clinical Data",
    "Accelerated Approval Confirmatory Study", "Rx To OTC Switch", "Comparative Efficacy Claim",
]


def canonical_type(text):
    """Map a (possibly clipped) supplement type to its canonical name.

    On some pages of the CY2023 report the type column is clipped in the PDF itself
    ("Labeling Change With Clinical", "Accelerated Approval Confirm"). Returns the
    canonical type and any leftover text that belongs to the next column.
    """
    t = " ".join(text.split())
    if not t:
        return "", ""
    for canon in sorted(CANONICAL_TYPES, key=len, reverse=True):
        if t.startswith(canon):
            return canon, t[len(canon):].strip()
    # clipped: the raw text is a prefix of a canonical type
    hits = [c for c in CANONICAL_TYPES if c.startswith(t)]
    if len(hits) == 1:
        return hits[0], ""
    # clipped prefix followed by leaked name tokens ("Manufacturing Change With CAMJE")
    words = t.split()
    for k in range(len(words), 0, -1):
        pre = " ".join(words[:k])
        hits = [c for c in CANONICAL_TYPES if c.startswith(pre)]
        if len(hits) == 1:
            return hits[0], " ".join(words[k:])
    return t, ""


def assign_col(x, starts):
    col = 0
    for i, s in enumerate(starts):
        if x >= s - 4:
            col = i
    return col


def parse_pdf(path):
    """Yield one dict per record. Sections (NDA, NDA SE8, BLA) each have their own header row."""
    # 1) flatten the document into lines, remembering page numbers
    all_lines = []
    with pdfplumber.open(path) as pdf:
        for pno, page in enumerate(pdf.pages, start=1):
            # phrases (blank-joined) give clean column left edges; tokens are what we assign
            phrases = page.extract_words(keep_blank_chars=True, x_tolerance=1.5, y_tolerance=2)
            tokens = page.extract_words(keep_blank_chars=False, x_tolerance=1.5, y_tolerance=2)
            tok_lines = {round(ln["top"]): ln["words"] for ln in cluster_lines(tokens)}
            for ln in cluster_lines(phrases):
                ln["page"] = pno
                key = min(tok_lines, key=lambda k: abs(k - ln["top"]))
                ln["tokens"] = tok_lines[key]
                all_lines.append(ln)
    # 2) split into sections: a section starts at a header line and ends at the next section heading
    sections, cur, section_name = [], None, "NDA Efficacy Supplements Approved"
    for ln in all_lines:
        first = ln["words"][0]["text"].strip()
        if SECTION_RE.match(first):
            section_name = first
            cur = None
            continue
        if is_header_line(ln):
            cur = {"name": section_name, "lines": []}
            sections.append(cur)
            continue
        if cur is None:
            continue  # title block / selection criteria
        # skip repeated title blocks on continuation pages
        if first.startswith(("CY 20", "As of ", "This report reflects", "Selection Criteria", "User Response", "Sort Order")):
            continue
        cur["lines"].append(ln)
    # 3) within each section, assign words to columns and glue wrapped lines to their anchor
    records = []
    for sec in sections:
        data_lines = [ln for ln in sec["lines"] if ln["words"]]
        # column edges can shift between pages of the same section (2023 BLA pages), so
        # derive them per page, falling back to the section-wide edges on short pages
        sec_starts = column_starts(data_lines)
        page_starts = {}
        for pg in {ln["page"] for ln in data_lines}:
            try:
                page_starts[pg] = column_starts([ln for ln in data_lines if ln["page"] == pg])
            except ValueError:
                page_starts[pg] = sec_starts
        pending = []
        for ln in data_lines:
            starts = page_starts[ln["page"]]
            first = ln["words"][0]["text"].strip()
            m = ANCHOR_RE.match(first)
            if m and round(ln["words"][0]["x0"]) <= starts[0] + 4:
                rec = {c: [] for c in COLS}
                rec["_page"], rec["_section"] = ln["page"], sec["name"]
                for cl in pending:  # wrapped first halves are printed above the anchor line
                    for w in cl["tokens"]:
                        rec[COLS[assign_col(w["x0"], starts)]].append(w["text"].strip())
                pending = []
                ws = ln["tokens"]
                rec["appl"].append(ws[0]["text"].strip() + " " + ws[1]["text"].strip())  # "NDA" "213217"
                rest = ws[2:]
                if rest and re.fullmatch(r"\(\d+\)", rest[0]["text"].strip()):  # e.g. "NDA 207131 (1)"
                    rec["appl"][-1] += " " + rest[0]["text"].strip()
                    rest = rest[1:]
                # the supplement number is right-aligned, so a long number (e.g. 5197) starts
                # left of the usual column edge; take the first token after the anchor if numeric
                if rest and rest[0]["text"].strip().isdigit():
                    rec["suppl_no"].append(rest[0]["text"].strip())
                    rest = rest[1:]
                for w in rest:
                    rec[COLS[assign_col(w["x0"], starts)]].append(w["text"].strip())
                records.append(rec)
            else:
                pending.append(ln)
        if pending and records:  # a wrapped second half below the last anchor of the section
            for cl in pending:
                for w in cl["tokens"]:
                    records[-1][COLS[assign_col(w["x0"], starts)]].append(w["text"].strip())
    out = []
    for r in records:
        row = {c: " ".join(x for x in r[c] if x) for c in COLS}
        row["supplement_type_raw"] = row["supplement_type"]
        row["supplement_type"], leftover = canonical_type(row["supplement_type"])
        if leftover:  # clipped pages print name tokens inside the type column
            row["established_name"] = (leftover + " " + row["established_name"]).strip()
        m = ANCHOR_RE.match(row["appl"])
        if not m:
            raise ValueError(f"unparsed anchor cell {row!r}")
        row["appl_type"], row["appl_no"] = m.group(1), m.group(2)
        row["appl_flag"] = m.group(3) or ""
        row["report_section"] = r["_section"]
        row["page"] = r["_page"]
        row["source_pdf"] = Path(path).name
        out.append(row)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdfs", nargs="+")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    rows = []
    for p in a.pdfs:
        rows.extend(parse_pdf(p))
    fields = ["appl_type", "appl_no", "suppl_no", "supplement_type", "supplement_type_raw", "established_name",
              "applicant", "priority", "approval_date", "appl_flag", "report_section", "page", "source_pdf"]
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
