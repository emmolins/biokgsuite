#!/usr/bin/env python3
"""Attach knowledge-graph-ready identifiers to data/candidates_precleaning.csv.

Drugs   -> ChEMBL, PubChem CID, CHEBI, UNII, RxCUI, MeSH, UMLS, DrugCentral, InChIKey (via NCATS Translator services)
           + DrugBank (by joining UNII / InChIKey / name to the DrugBank open-data vocabulary, --drugbank-vocab)
Diseases-> MONDO, then DOID, MeSH, UMLS, OMIM, Orphanet, ICD-10-CM       (via Name Resolver + mondo.sssom.tsv)

Services (all free, no key):
  Name Resolver   https://name-resolution-sri.renci.org/lookup?string=...&biolink_type=...&limit=N
                  free text -> ranked Biolink CURIEs (drug names -> CHEBI/DRUGBANK/UNII..., disease phrases -> MONDO)
  Node Normalizer https://nodenormalization-sri.renci.org/get_normalized_nodes?curie=...&drug_chemical_conflate=true
                  any CURIE -> its full equivalence set (this is what Every Cure's MATRIX uses for node IDs);
                  drug_chemical_conflate merges salts/esters onto the parent drug (cabozantinib malate -> cabozantinib)
  MONDO SSSOM     https://raw.githubusercontent.com/monarch-initiative/mondo/d50a5d1a6d728fe52063b9f84f9a19cb56ca7333/src/ontology/mappings/mondo.sssom.tsv
                  official MONDO cross-references with mapping predicates (exact / broad)

Every API response is cached in raw/normalisation/cache.json, so a second run (or `--offline`) is fully
reproducible without network access and the shipped snapshot re-normalises identically.

What is normalised:
  * drug: for FDA rows the UNII from openFDA is used directly (no name lookup needed); for the other regulators
    each ingredient string is looked up by name. Salt suffixes are stripped before lookup (see SALT_RE) and
    conflation is on, so the returned DrugBank/ChEMBL IDs are the parent drug.
  * disease: only rows that carry indication text (TGA, HC, PMDA). A disease phrase is extracted with
    INDICATION_RE (e.g. "... indicated for the treatment of adult patients with X" -> X); FDA and EMA rows have no
    text yet and are left for the label/EPAR step. Matches below --min-score, or with a runner-up within
    --ambiguity of the top score, are flagged needs_review.

Outputs:
  data/candidates_normalised.csv   the pre-cleaning table + drug_* and disease_* columns
  data/review_queue.csv            rows needing a human decision, with the top 3 candidates for each

Usage:
    python scripts/normalise.py                          # live: fills the cache as it goes
    python scripts/normalise.py --offline                # cache only (fully reproducible)
    python scripts/normalise.py --plan requests.json     # list the API requests a live run would make
    python scripts/normalise.py --drugbank-vocab drugbank_vocabulary.csv   # add DrugBank IDs

Note: DrugBank identifiers are NOT in the Translator equivalence sets (DrugBank licensing), so they come from the
DrugBank open-data vocabulary CSV, which you download yourself (free account, CC BY-NC 4.0) and pass with
--drugbank-vocab. Without it the DrugBank column is empty and the other identifiers are still filled.
The run writes data/normalisation_provenance.json (timestamp, service versions, cache size, vocabulary path).
"""
import argparse
import csv
import json
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

import requests

NAME_RESOLVER = "https://name-resolution-sri.renci.org/lookup"
NODE_NORM = "https://nodenormalization-sri.renci.org/get_normalized_nodes"
CACHE_PATH = Path("raw/normalisation/cache.json")
SSSOM_PATH = Path("raw/normalisation/mondo.sssom.tsv")

DRUG_PREFIXES = ["DRUGBANK", "CHEMBL.COMPOUND", "PUBCHEM.COMPOUND", "CHEBI", "UNII", "RXCUI", "MESH", "UMLS", "DrugCentral", "INCHIKEY"]
DISEASE_XREF_PREFIXES = ["DOID", "mesh", "UMLS", "OMIM", "Orphanet", "ICD10CM"]
DRUG_TYPES = "ChemicalEntity"  # Name Resolver accepts ONE biolink_type; ChemicalEntity also covers antibodies (typed via UNII)
DISEASE_TYPES = "DiseaseOrPhenotypicFeature"  # superclass of Disease and PhenotypicFeature

SALT_RE = re.compile(
    r"\b(hydrochloride|hydrobromide|mesilate|mesylate|maleate|malate|\(s\)-malate|fumarate|succinate|tartrate|citrate|"
    r"sodium|potassium|calcium|magnesium|acetate|sulfate|sulphate|phosphate|besilate|besylate|tosilate|tosylate|"
    r"hydrate|monohydrate|dihydrate|sesquihydrate|hemihydrate|trihydrate|anhydrous|dimesylate|ditosylate|"
    r"for injection|injection|\(genetical recombination\)|genetical recombination)\b", re.I)
INDICATION_RE = re.compile(
    r"indicated\s+(?:for|as|in)\s+(?:the\s+)?(?:(?:treatment|prevention|management|prophylaxis|reduction|control)\s+(?:of\s+)?)?"
    r"(?:(?:adult|adults|paediatric|pediatric|adolescent)\s+)?(?:(?:and\s+\w+\s+)?patients?\s+)?(?:aged\s+[^,]+?,\s*)?(?:with|of|for)?\s*"
    r"(.+?)(?:\s+(?:who|whose|that|which|when|after|following|in\s+(?:combination|adults|patients)|as\s+(?:a|an|monotherapy)|at\s+high\s+risk)\b|[.;:]|$)",
    re.I | re.S)
HC_PREFIX_RE = re.compile(r"^(?:new indication|additional indication|indication extension|expansion of (?:the )?indication)\s*[:\-]\s*([^:]+?)(?::|\.|$)", re.I)


# ----------------------------------------------------------------------------- helpers
class Cache:
    def __init__(self, path, offline, plan=False):
        self.path, self.offline, self.plan = path, offline, plan
        self.d = json.loads(path.read_text()) if path.exists() else {}
        self.dirty = 0
        self.missing = {}  # key -> {url, params}; filled in --plan mode

    def get(self, key, fetch, request=None):
        if key in self.d:
            return self.d[key]
        if self.plan:
            self.missing[key] = request
            return None
        if self.offline:
            return None
        val = fetch()
        self.d[key] = val
        self.dirty += 1
        if self.dirty % 25 == 0:
            self.save()
        return val

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.d, indent=0, sort_keys=True))


def http_json(url, params, retries=4):
    for i in range(retries):
        try:
            r = requests.get(url, params=params, timeout=60, headers={"User-Agent": "repurposing-dataset/0.1"})
            if r.status_code == 200:
                time.sleep(0.2)
                return r.json()
        except requests.RequestException:
            pass
        time.sleep(1.5 * (i + 1))
    return {"_error": f"failed {url}"}


def slim_nr(resp):
    """Keep only the Name Resolver fields the pipeline uses (synonym lists are large and unused)."""
    if not isinstance(resp, list):
        return resp
    return [{k: v for k, v in hit.items() if k not in ("synonyms", "highlighting", "taxa")} for hit in resp]


def name_lookup(cache, text, types, limit=5):
    key = f"nr|{types}|{text.lower()}"
    params = {"string": text, "biolink_type": types, "limit": limit, "autocomplete": "false"}
    return cache.get(key, lambda: slim_nr(http_json(NAME_RESOLVER, params)), {"url": NAME_RESOLVER, "params": params})


NN_KEEP = {"DRUGBANK", "CHEMBL.COMPOUND", "PUBCHEM.COMPOUND", "CHEBI", "UNII", "RXCUI", "MESH", "UMLS", "DrugCentral",
           "INCHIKEY", "MONDO", "DOID", "NCIT"}


def slim_nn(resp):
    """Keep only the identifier prefixes the pipeline uses, at most 5 per prefix (conflated drug cliques can carry
    hundreds of PubChem CIDs). n_equivalent_identifiers_total records the original clique size."""
    if not isinstance(resp, dict):
        return resp
    out = {}
    for curie, node in resp.items():
        if not node:
            out[curie] = node
            continue
        cnt, eq = {}, []
        for e in node.get("equivalent_identifiers", []):
            p = e["identifier"].split(":")[0]
            if p in NN_KEEP and cnt.get(p, 0) < 5:
                cnt[p] = cnt.get(p, 0) + 1
                eq.append({k: e[k] for k in ("identifier", "label") if k in e})
        out[curie] = {"id": node.get("id"), "equivalent_identifiers": eq, "type": node.get("type", [])[:1],
                      "n_equivalent_identifiers_total": len(node.get("equivalent_identifiers", []))}
    return out


def normalize_curie(cache, curie, conflate=True):
    key = f"nn|{'c' if conflate else 'n'}|{curie}"
    params = {"curie": curie, "conflate": "true", "drug_chemical_conflate": "true" if conflate else "false"}
    return cache.get(key, lambda: slim_nn(http_json(NODE_NORM, params)), {"url": NODE_NORM, "params": params})


def service_versions():
    """Record the deployed versions of the two Translator services (from their OpenAPI documents)."""
    out = {}
    for name, base in (("name_resolver", NAME_RESOLVER.rsplit("/", 1)[0]), ("node_normalizer", NODE_NORM.rsplit("/", 1)[0])):
        try:
            info = requests.get(base + "/openapi.json", timeout=30).json().get("info", {})
            out[name] = {"title": info.get("title"), "version": info.get("version")}
        except Exception as e:  # noqa: BLE001
            out[name] = {"error": str(e)}
    return out


def load_drugbank_vocab(path):
    """DrugBank open-data vocabulary CSV (https://go.drugbank.com/releases/latest#open-data, CC BY-NC 4.0, free
    account required to download; not redistributed here). Columns: DrugBank ID, Accession Numbers, Common name,
    CAS, UNII, Synonyms, Standard InChI Key. Returns lookups by UNII, InChIKey and lower-cased name/synonym."""
    by_unii, by_inchikey, by_name = {}, {}, {}
    if not path:
        return by_unii, by_inchikey, by_name
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            dbid = r["DrugBank ID"]
            if r.get("UNII"):
                by_unii[r["UNII"].strip()] = dbid
            if r.get("Standard InChI Key"):
                by_inchikey[r["Standard InChI Key"].strip()] = dbid
            for n in [r.get("Common name", "")] + (r.get("Synonyms", "") or "").split(" | "):
                if n.strip():
                    by_name.setdefault(n.strip().lower(), dbid)
    return by_unii, by_inchikey, by_name


def equivalents(nn_response, curie):
    """Node Normalizer -> {prefix: [ids]} plus the preferred label."""
    out = defaultdict(list)
    if not nn_response or not isinstance(nn_response, dict):
        return out, ""
    node = nn_response.get(curie)
    if not node:
        return out, ""
    for eq in node.get("equivalent_identifiers", []):
        pfx, _, local = eq["identifier"].partition(":")
        if local not in out[pfx]:
            out[pfx].append(local)
    return out, node.get("id", {}).get("label", "")


STOP = {"with", "the", "and", "or", "of", "in", "for", "to", "adult", "adults", "patients", "patient", "disease",
        "disorder", "type", "cancer", "carcinoma", "syndrome", "chronic", "acute", "severe", "moderate", "active",
        "advanced", "metastatic", "unresectable", "recurrent", "relapsed", "refractory", "positive", "negative"}


def tokens(text):
    return {t for t in re.findall(r"[a-z0-9]+", (text or "").lower()) if len(t) >= 4 and t not in STOP}


def label_mismatch(query, label):
    """True when the resolved label shares no informative token with the query (e.g. a pneumococcal vaccine
    resolving to tuberculin PPD). Purely a review trigger; it never changes the mapping."""
    q, l = tokens(query), tokens(label)
    if not q or not l:
        return False
    return not (q & l) and not any(a[:5] == b[:5] for a in q for b in l)


def split_ingredients(s):
    parts = re.split(r"\s*;\s*|\s+/\s+|\s*,\s*(?![^()]*\))", s)
    return [p.strip() for p in parts if p.strip()]


def clean_drug_name(s):
    s = re.sub(r"\(.*?\)", " ", s)  # drop parentheticals such as "(genetical recombination)"
    s = SALT_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip(" ,-")


def extract_disease_phrase(regulator, text):
    """Best-effort disease phrase from the regulator's indication text; empty string if none found."""
    raw_first = (text or "").strip().split("\n")[0].strip()
    t = re.sub(r"\s+", " ", text or "").strip()
    if not t:
        return ""
    if regulator == "TGA" and 3 <= len(raw_first) <= 80 and "indicated" not in raw_first.lower() and not raw_first.endswith(":"):
        return raw_first  # TGA pages usually open with a heading line naming the disease
    if regulator == "HC":
        m = HC_PREFIX_RE.match(t)
        if m and len(m.group(1)) < 120 and not re.search(r"\bindicated\b", m.group(1), re.I):
            return m.group(1).strip()
    if regulator == "PMDA":
        m = re.search(r"(?:for|in)\s+(?:the\s+)?(?:treatment|prevention|management|prophylaxis|control|diagnosis)\s+(?:of|for)\s+(.+?)(?:\s+in\s+patients|\.|\[|$)", t, re.I)
        if m:
            return m.group(1).strip()
    m = INDICATION_RE.search(t)
    if m:
        phrase = m.group(1).strip(" ,")
        if 3 <= len(phrase) <= 160:
            return phrase
    return ""


def load_sssom(path):
    xrefs = defaultdict(lambda: defaultdict(list))
    labels = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 4 or parts[0] == "subject_id":
                continue
            subj, subj_label, pred, obj = parts[0], parts[1], parts[2], parts[3]
            pfx, _, local = obj.partition(":")
            if pfx in DISEASE_XREF_PREFIXES:
                tag = local if pred.endswith("exactMatch") else f"{local}~{pred.split(':')[-1]}"
                xrefs[subj][pfx].append(tag)
            labels[subj] = subj_label
    return xrefs, labels


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="data/candidates_precleaning.csv")
    ap.add_argument("--fda-interim", default="interim/fda_candidates.csv")
    ap.add_argument("--out", default="data/candidates_normalised.csv")
    ap.add_argument("--review", default="data/review_queue.csv")
    ap.add_argument("--offline", action="store_true", help="use raw/normalisation/cache.json only; never call the APIs")
    ap.add_argument("--plan", metavar="FILE", help="do not call the APIs; write the missing requests to FILE as JSON and exit")
    ap.add_argument("--drugbank-vocab", default="", help="path to the DrugBank open-data vocabulary CSV (adds DrugBank IDs)")
    ap.add_argument("--min-score", type=float, default=0.0, help="Name Resolver score below which a match needs review")
    ap.add_argument("--ambiguity", type=float, default=0.8, help="flag if runner-up score >= this fraction of the top score")
    a = ap.parse_args()

    cache = Cache(CACHE_PATH, a.offline, plan=bool(a.plan))
    db_by_unii, db_by_inchikey, db_by_name = load_drugbank_vocab(a.drugbank_vocab)
    if not SSSOM_PATH.exists():
        raise SystemExit(f"{SSSOM_PATH} missing: curl -o {SSSOM_PATH} https://raw.githubusercontent.com/monarch-initiative/mondo/d50a5d1a6d728fe52063b9f84f9a19cb56ca7333/src/ontology/mappings/mondo.sssom.tsv")
    xrefs, mondo_labels = load_sssom(SSSOM_PATH)
    fda_unii = {}
    with open(a.fda_interim, newline="") as f:
        for r in csv.DictReader(f):
            fda_unii[f"{r['appl_no']}-{r['suppl_no']}"] = r["unii"]

    with open(a.inp, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    out_rows, review = [], []
    for r in rows:
        o = dict(r)
        reasons = []
        # ------------------------------------------------------------- drug
        ids = defaultdict(list)
        labels, queries, scores = [], [], []
        curies = []
        if r["regulator"] == "FDA" and fda_unii.get(r["source_row_id"]):
            for u in fda_unii[r["source_row_id"]].split("; "):
                curies.append((f"UNII:{u}", "openFDA UNII", 1.0, ""))
        else:
            for ing in split_ingredients(r["active_ingredient"] or r["product_name"]):
                q = clean_drug_name(ing)
                if len(q) < 3 or q.isdigit() or re.fullmatch(r"[\dA-Z]{1,3}", q):
                    continue  # fragments of serotype lists ("3", "6A", "19F"), not ingredient names
                resp = name_lookup(cache, q, DRUG_TYPES)
                queries.append(q)
                if not resp or isinstance(resp, dict):
                    reasons.append(f"drug lookup unavailable: {q}")
                    continue
                if not resp:
                    reasons.append(f"drug not found: {q}")
                    continue
                top = resp[0]
                if len(resp) > 1 and resp[1].get("score", 0) >= a.ambiguity * top.get("score", 0) and resp[1]["curie"] != top["curie"]:
                    reasons.append(f"drug ambiguous: {q} -> {top['curie']} ({top.get('label')}) vs {resp[1]['curie']} ({resp[1].get('label')})")
                curies.append((top["curie"], "Name Resolver", top.get("score", 0), q))
        for curie, src, score, q in curies:
            eq, label = equivalents(normalize_curie(cache, curie), curie)
            if not eq:
                reasons.append(f"no normalizer record for {curie}")
                continue
            for p in DRUG_PREFIXES:
                for v in eq.get(p, []):
                    if v not in ids[p]:
                        ids[p].append(v)
            labels.append(label)
            scores.append(f"{src}:{score:.2f}")
            if src == "Name Resolver" and label_mismatch(q, label):
                reasons.append(f"drug label mismatch: {q} -> {label}")
        # DrugBank is not part of the Translator equivalence sets; join the open vocabulary on UNII, then InChIKey, then name
        db_src = ""
        for u in ids["UNII"]:
            if u in db_by_unii and db_by_unii[u] not in ids["DRUGBANK"]:
                ids["DRUGBANK"].append(db_by_unii[u]); db_src = db_src or "vocab:UNII"
        if not ids["DRUGBANK"]:
            for k in ids["INCHIKEY"]:
                if k in db_by_inchikey:
                    ids["DRUGBANK"].append(db_by_inchikey[k]); db_src = "vocab:InChIKey"; break
        if not ids["DRUGBANK"]:
            for nm in labels + queries:
                if nm and nm.lower() in db_by_name:
                    ids["DRUGBANK"].append(db_by_name[nm.lower()]); db_src = "vocab:name"; break
        o["drug_drugbank_source"] = db_src
        for p in DRUG_PREFIXES:
            o["drug_" + p.replace(".", "_").lower()] = "; ".join(ids[p])
        o["drug_label"] = "; ".join(labels)
        o["drug_query"] = "; ".join(queries)
        o["drug_match"] = "; ".join(scores)
        if not ids["UNII"] and not ids["CHEMBL.COMPOUND"] and not [x for x in reasons if x.startswith("drug")]:
            reasons.append("drug not resolved to any identifier")
        if db_by_unii and not ids["DRUGBANK"]:
            reasons.append("no DrugBank id (not in vocabulary: vaccine, radiopharmaceutical, or name mismatch)")
        # ------------------------------------------------------------- disease
        phrase = extract_disease_phrase(r["regulator"], r["indication_text"])
        o["disease_query"] = phrase
        o.update({k: "" for k in ("mondo_id", "mondo_label", "disease_match", "disease_candidates")})
        for p in DISEASE_XREF_PREFIXES:
            o["disease_" + p.lower()] = ""
        if not r["indication_text"]:
            reasons.append("no indication text (take from label/EPAR)")
        elif not phrase or len(phrase) < 4 or phrase.lower() in ("use", "adult", "the treatment of"):
            phrase = ""
            o["disease_query"] = ""
            reasons.append("could not extract a disease phrase")
        else:
            resp = name_lookup(cache, phrase, DISEASE_TYPES)
            if not resp or isinstance(resp, dict):
                reasons.append("disease lookup unavailable")
            else:
                mondo = [x for x in resp if x["curie"].startswith("MONDO:")] or resp
                top = mondo[0]
                o["mondo_id"], o["mondo_label"] = top["curie"], top.get("label", "")
                o["disease_match"] = f"{top.get('score', 0):.2f}"
                o["disease_candidates"] = " | ".join(f"{x['curie']} {x.get('label','')} ({x.get('score',0):.2f})" for x in mondo[:3])
                if top.get("score", 0) < a.min_score:
                    reasons.append("disease match score low")
                if len(mondo) > 1 and mondo[1].get("score", 0) >= a.ambiguity * top.get("score", 0):
                    reasons.append("disease ambiguous")
                if not top["curie"].startswith("MONDO:"):
                    reasons.append("no MONDO term among candidates")
                if label_mismatch(phrase, top.get("label", "")):
                    reasons.append(f"disease label mismatch: {phrase[:60]} -> {top.get('label', '')}")
                for p in DISEASE_XREF_PREFIXES:
                    o["disease_" + p.lower()] = "; ".join(xrefs.get(top["curie"], {}).get(p, []))
        o["needs_review"] = bool(reasons)
        o["review_reason"] = " | ".join(reasons)
        out_rows.append(o)
        if reasons:
            review.append({k: o[k] for k in ("candidate_id", "regulator", "product_name", "active_ingredient", "drug_query",
                                             "drug_drugbank", "drug_label", "disease_query", "mondo_id", "mondo_label",
                                             "disease_candidates", "review_reason")})
    if a.plan:
        Path(a.plan).write_text(json.dumps([{"key": k, **v} for k, v in cache.missing.items()], indent=0))
        print(f"{len(cache.missing)} API requests not in cache -> {a.plan}", file=sys.stderr)
        return
    cache.save()
    prov = {"run_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "offline": a.offline,
            "cache_entries": len(cache.d), "drugbank_vocab": a.drugbank_vocab or None,
            "services": (json.loads(CACHE_PATH.with_name("service_versions.json").read_text())
                         if a.offline and CACHE_PATH.with_name("service_versions.json").exists() else service_versions())}
    if not a.offline:
        CACHE_PATH.with_name("service_versions.json").write_text(json.dumps(prov["services"], indent=1))
    Path(a.out).with_name("normalisation_provenance.json").write_text(json.dumps(prov, indent=1))
    fields = list(out_rows[0].keys())
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(out_rows)
    with open(a.review, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(review[0].keys()) if review else ["candidate_id"])
        w.writeheader()
        w.writerows(review)
    n_db = sum(1 for o in out_rows if o["drug_drugbank"])
    n_mondo = sum(1 for o in out_rows if o["mondo_id"])
    n_text = sum(1 for r in rows if r["indication_text"])
    print(f"{len(out_rows)} rows: DrugBank id for {n_db}; MONDO id for {n_mondo} of {n_text} rows with indication text; "
          f"{len(review)} rows in review queue -> {a.out}, {a.review}", file=sys.stderr)


if __name__ == "__main__":
    main()
