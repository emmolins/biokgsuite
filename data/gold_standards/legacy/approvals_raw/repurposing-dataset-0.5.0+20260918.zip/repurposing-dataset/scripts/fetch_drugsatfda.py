#!/usr/bin/env python3
"""Fetch "Supplement Categories or Approval Type" for every NDA in the openFDA universe from Drugs@FDA.

Page: https://www.accessdata.fda.gov/scripts/cder/daf/index.cfm?event=overview.process&ApplNo=<6 digits>
Table id "exampleApplSuppl": Action Date | Submission | Supplement Categories or Approval Type | Letters, Reviews,
Labels | Note. Categories look like "Efficacy-New Indication", "Efficacy-New Patient Population",
"Labeling-Package Insert", and can be comma-separated combinations. BLAs are listed as plain "Supplement"
(no category), so only NDAs are fetched. Drugs@FDA answers HTTP 403 to bursts: keep it sequential, ~1 req/s.

Usage:
    python scripts/fetch_drugsatfda.py --openfda raw/fda/openfda_efficacy_supplements_2023plus.json \
        --start 2023 -o raw/fda/drugsatfda_supplement_categories.json
"""
import argparse
import json
import re
from pathlib import Path

from bs4 import BeautifulSoup

from common import get, now_iso, session

URL = "https://www.accessdata.fda.gov/scripts/cder/daf/index.cfm?event=overview.process&ApplNo={}"


def parse_supplement_table(html, appl_no, min_year):
    soup = BeautifulSoup(html, "lxml")
    t = soup.find("table", id="exampleApplSuppl")
    rows = []
    if t is None:
        return None
    for tr in t.select("tbody tr"):
        c = tr.find_all("td")
        if len(c) < 3:
            continue
        date = c[0].get_text(strip=True)
        if not re.search(r"/(\d{4})$", date) or int(date[-4:]) < min_year:
            continue
        rows.append({
            "appl_no": appl_no,
            "action_date": date,
            "submission": c[1].get_text(strip=True),
            "category": re.sub(r"\s+", " ", c[2].get_text(" ", strip=True)),
            "docs": [{"t": a.get_text(strip=True), "u": a.get("href")} for a in (c[3].find_all("a") if len(c) > 3 else [])],
            "note": c[4].get_text(strip=True) if len(c) > 4 else "",
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--openfda", default="raw/fda/openfda_efficacy_supplements_2023plus.json")
    ap.add_argument("--start", type=int, default=2023)
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    apps = sorted({x["application_number"][3:] for x in json.load(open(a.openfda))["results"] if x["application_number"].startswith("NDA")})
    s = session()
    rows, errors = [], []
    for i, ap_no in enumerate(apps, 1):
        try:
            r = get(s, URL.format(ap_no), sleep=1.0)
            parsed = parse_supplement_table(r.text, ap_no, a.start)
            if parsed is None:
                errors.append([ap_no, "no supplement table"])
            else:
                rows.extend(parsed)
        except Exception as e:  # noqa: BLE001
            errors.append([ap_no, str(e)])
        if i % 25 == 0:
            print(f"{i}/{len(apps)} applications, {len(rows)} supplement rows")
    out = {"fetched_at": now_iso(), "source": URL.format("<ApplNo>") + "  (table #exampleApplSuppl)",
           "n_applications": len(apps), "n_rows": len(rows), "errors": errors, "rows": rows}
    Path(a.out).write_text(json.dumps(out, indent=1))
    print(f"{len(rows)} rows, {len(errors)} errors -> {a.out}")


if __name__ == "__main__":
    main()
