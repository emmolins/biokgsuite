#!/usr/bin/env python3
"""Download the PMDA English "List of Approved Drugs" (New Drugs) PDF.

Index: https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html
The page links one cumulative PDF ("April 2004 to <month year>", ~3 MB, ~200 pages, most recent first).
The file id changes when PMDA re-issues it, so the link is resolved from the page each time.

Usage:
    python scripts/fetch_pmda.py -o raw/pmda
"""
import argparse
import re
from pathlib import Path

from bs4 import BeautifulSoup

from common import get, session, write_manifest

INDEX = "https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default="raw/pmda")
    a = ap.parse_args()
    s = session()
    soup = BeautifulSoup(get(s, INDEX).text, "lxml")
    link = None
    for a_ in soup.find_all("a", href=True):
        if a_["href"].lower().endswith(".pdf") and re.search(r"April 2004 to", a_.get_text(" ", strip=True)):
            link = a_
            break
    if link is None:
        raise SystemExit("could not find the 'April 2004 to ...' PDF link on the PMDA page")
    url = link["href"] if link["href"].startswith("http") else "https://www.pmda.go.jp" + link["href"]
    label = re.sub(r"\s+", " ", link.get_text(" ", strip=True))
    r = get(s, url)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    p = out / "pmda_list_of_approved_drugs.pdf"
    p.write_bytes(r.content)
    write_manifest(out / "MANIFEST.json", index=INDEX, pdf_url=url, label=label, bytes=len(r.content))
    print(f"{label}: {url} -> {p} ({len(r.content)} bytes)")


if __name__ == "__main__":
    main()
