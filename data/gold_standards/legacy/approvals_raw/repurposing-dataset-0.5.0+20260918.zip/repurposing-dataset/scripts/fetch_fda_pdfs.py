#!/usr/bin/env python3
"""Download the FDA "NDA and BLA Efficacy Supplement Calendar Year Approvals" PDF reports.

Index page: https://www.fda.gov/drugs/nda-and-bla-approvals/efficacy-supplement-approvals
Links are of the form https://www.fda.gov/media/<id>/download?attachment with the year in the link text.
Known ids at the time of writing: 2023 -> 177086, 2024 -> 185465, 2025 -> 191372 (the 2026 report will be added
to the same page in early 2027). The script scrapes the index so new years are picked up automatically.

Usage:
    python scripts/fetch_fda_pdfs.py --years 2023 2024 2025 -o raw/fda
"""
import argparse
import re
from pathlib import Path

from bs4 import BeautifulSoup

from common import get, session, write_manifest

INDEX = "https://www.fda.gov/drugs/nda-and-bla-approvals/efficacy-supplement-approvals"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--years", nargs="+", type=int, default=[2023, 2024, 2025, 2026])
    ap.add_argument("-o", "--out", default="raw/fda")
    a = ap.parse_args()
    s = session()
    soup = BeautifulSoup(get(s, INDEX).text, "lxml")
    found = {}
    for link in soup.find_all("a", href=True):
        m = re.search(r"Efficacy Supplement Calendar Year Approvals:\s*(\d{4})", link.get_text(" ", strip=True))
        if m and "/media/" in link["href"]:
            found[int(m.group(1))] = link["href"] if link["href"].startswith("http") else "https://www.fda.gov" + link["href"]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    got = {}
    for y in a.years:
        if y not in found:
            print(f"no report for {y} on the index page (expected for the current year)")
            continue
        r = get(s, found[y])
        p = out / f"efficacy_supplements_CY{y}.pdf"
        p.write_bytes(r.content)
        got[y] = {"url": found[y], "bytes": len(r.content)}
        print(f"{y}: {found[y]} -> {p} ({len(r.content)} bytes)")
    write_manifest(out / "MANIFEST_pdfs.json", index=INDEX, reports=got)


if __name__ == "__main__":
    main()
