#!/usr/bin/env python3
"""Fetch every CDER NDA/BLA with an approved EFFICACY supplement dated >= START from the openFDA Drugs@FDA API.

API: https://open.fda.gov/apis/drug/drugsfda/   (no key needed for <1000 req/day; add ?api_key=... if you have one)
The search matches at application level (any submission EFFICACY AND any submission in the date range), so the
per-supplement filter is applied client-side. Output mirrors what fda_build.py expects:
  {fetched_at, query, n_applications, n_supplements, results:[{application_number, sponsor_name, openfda{...},
   products[...], submissions[{submission_number, submission_status_date, review_priority, application_docs[...]}]}]}

Usage:
    python scripts/fetch_openfda.py --start 20230101 -o raw/fda/openfda_efficacy_supplements_2023plus.json
"""
import argparse
import json
from pathlib import Path

from common import get, now_iso, session

BASE = "https://api.fda.gov/drug/drugsfda.json"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="20230101")
    ap.add_argument("--end", default="20991231")
    ap.add_argument("--api-key", default="")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    s = session()
    query = f"submissions.submission_class_code:EFFICACY AND submissions.submission_status_date:[{a.start} TO {a.end}]"
    results, skip = [], 0
    while True:
        params = {"search": query, "limit": 1000, "skip": skip}
        if a.api_key:
            params["api_key"] = a.api_key
        j = get(s, BASE, params=params).json()
        results.extend(j["results"])
        total = j["meta"]["results"]["total"]
        skip += 1000
        if skip >= total or not j["results"]:
            break
    slim = []
    for app in results:
        subs = [
            {
                "submission_number": x["submission_number"],
                "submission_status_date": x.get("submission_status_date", ""),
                "review_priority": x.get("review_priority", ""),
                "submission_class_code_description": x.get("submission_class_code_description", ""),
                "application_docs": [{"type": d.get("type"), "url": d.get("url"), "date": d.get("date")} for d in x.get("application_docs", [])],
            }
            for x in app.get("submissions", [])
            if x.get("submission_type") == "SUPPL" and x.get("submission_class_code") == "EFFICACY"
            and x.get("submission_status") == "AP" and a.start <= x.get("submission_status_date", "") <= a.end
        ]
        if not subs:
            continue
        o = app.get("openfda") or {}
        slim.append({
            "application_number": app["application_number"],
            "sponsor_name": app.get("sponsor_name", ""),
            "openfda": {k: o.get(k) for k in ("brand_name", "generic_name", "substance_name", "unii", "rxcui")} if o else None,
            "products": [{k: p.get(k) for k in ("brand_name", "active_ingredients", "dosage_form", "route", "marketing_status")} for p in app.get("products", [])],
            "submissions": subs,
        })
    out = {"fetched_at": now_iso(), "query": query, "n_applications": len(slim),
           "n_supplements": sum(len(x["submissions"]) for x in slim), "results": slim}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(out, indent=1))
    print(f"{out['n_applications']} applications, {out['n_supplements']} efficacy supplements -> {a.out}")


if __name__ == "__main__":
    main()
