#!/usr/bin/env python3
"""EMA: extract CHMP recommendations on extensions of therapeutic indication from the monthly
"Meeting highlights from the CHMP" news pages.

Source pages (one per CHMP meeting; the list is produced by fetch_ema.py or given explicitly):
  https://www.ema.europa.eu/en/news/meeting-highlights-committee-medicinal-products-human-use-chmp-<dd>-<dd>-<month>-<yyyy>

Each page has a "Positive recommendations on extensions of (therapeutic) indications" section
followed by one card per medicine. Two page templates exist:
  * 2023: a <table> per medicine with rows "Name of medicine | INN | Marketing-authorisation holder | More information"
  * 2024 onward: a <div class="description-list"> per medicine with <dt>/<dd> pairs and the name as heading
  The section heading is usually "Positive recommendations on extensions of (therapeutic) indications";
  a few pages (Jul 2024, Dec 2024, Jan 2025) use "Positive recommendations on new therapeutic indications".
This parser walks the page's section container (.ema-node-content-wrapper.node-sections) in order,
tracks the current section heading, and emits every medicine card found under an extension section.
It also emits cards under "Negative ..." / "outside the EU" extension sections with a flag so nothing is
silently dropped. The CHMP opinion is NOT the EU authorisation: the European Commission decision follows
about two months later; both dates should be recorded in the cleaning step (EPAR page "changes since
initial authorisation" or the Union Register).

Usage:
    python scripts/ema_parse_chmp_highlights.py raw/ema/*.html -o interim/ema_candidates.csv
"""
import argparse
import csv
import re
import sys
from pathlib import Path

from bs4 import BeautifulSoup

EXT_RE = re.compile(r"extensions?\s+of\s+(therapeutic\s+)?indications?|new\s+therapeutic\s+indications?", re.I)
FIELDS = ["regulator", "meeting", "meeting_url", "chmp_opinion_published", "section", "opinion_polarity",
          "outside_eu", "medicine", "inn", "mah", "more_information", "epar_url", "source_file"]


def text(el):
    return re.sub(r"\s+", " ", el.get_text(" ", strip=True)).strip()


def parse_card(item):
    """Return dict(medicine, inn, mah, more_information, epar_url) or None if `item` is not a medicine card."""
    pairs = {}
    href = ""
    tbl = item.find("table")
    if tbl:
        for tr in tbl.find_all("tr"):
            tds = tr.find_all(["td", "th"])
            if len(tds) >= 2:
                k, v = text(tds[0]), text(tds[1])
                pairs[k] = v
                a = tds[1].find("a")
                if a and a.get("href"):
                    href = a["href"]
    dl = item.find("dl") or item.select_one(".description-list")
    if dl:
        for dt in dl.find_all("dt"):
            dd = dt.find_next_sibling("dd")
            if dd is not None:
                pairs[text(dt)] = text(dd)
                a = dd.find("a")
                if a and a.get("href") and not href:
                    href = a["href"]
        if "Name of medicine" not in pairs:
            h = item.find(["h2", "h3", "h4"])
            if h:
                pairs["Name of medicine"] = text(h)
    if not pairs:
        return None
    inn_key = next((k for k in pairs if k.upper().startswith("INN") or "non-proprietary" in k.lower()), None)
    mah_key = next((k for k in pairs if "authorisation" in k.lower()), None)
    name = pairs.get("Name of medicine", "")
    if not name:
        return None
    return {
        "medicine": name.rstrip("*").strip(),
        "inn": pairs.get(inn_key, "") if inn_key else "",
        "mah": pairs.get(mah_key, "") if mah_key else "",
        "more_information": pairs.get("More information", ""),
        "epar_url": ("https://www.ema.europa.eu" + href) if href.startswith("/") else href,
    }


def parse_page(path):
    raw = Path(path).read_text(encoding="utf-8")
    meta = dict(re.findall(r"^(?:<!--)?\s*(source|title|published):\s*(.*?)\s*$", raw.split("-->", 1)[0], re.M)) if raw.startswith("<!--") else {}
    soup = BeautifulSoup(raw, "lxml")
    wrapper = soup.select_one(".ema-node-content-wrapper.node-sections") or soup
    meeting = re.sub(r".*\(CHMP\)\s*", "", meta.get("title", Path(path).stem))
    rows = []
    section = ""
    for item in wrapper.find_all("div", class_="item", recursive=False) or wrapper.find_all(recursive=False):
        h = item.find(["h2", "h3"])
        if h and not item.find("table") and not item.select_one(".description-list"):
            section = text(h)
            continue
        if h and (item.find("table") or item.select_one(".description-list")) and not item.select_one(".description-list"):
            # 2023 template: the first card of a section carries the heading in the same item
            section = text(h)
        if not EXT_RE.search(section):
            continue
        card = parse_card(item)
        if not card:
            continue
        rows.append({
            "regulator": "EMA",
            "meeting": meeting,
            "meeting_url": meta.get("source", ""),
            "chmp_opinion_published": meta.get("published", "")[:10],
            "section": section,
            "opinion_polarity": ("withdrawal" if re.search(r"withdraw", section, re.I)
                                 else "negative" if re.search(r"negative", section, re.I) else "positive"),
            "outside_eu": bool(re.search(r"outside the EU", section, re.I)),
            **card,
            "source_file": Path(path).name,
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pages", nargs="+")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    rows = []
    for p in sorted(a.pages):
        rows.extend(parse_page(p))
    rows.sort(key=lambda r: (r["chmp_opinion_published"], r["medicine"]))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} extension-of-indication opinions from {len(a.pages)} pages -> {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
