#!/usr/bin/env python3
"""Extract the indication sentence from FDA approval letters (raw/fda/letters/approval_letter_text.json).

An efficacy-supplement approval letter states, on page 1, what the supplement "provides for":
    "This Prior Approval supplemental new drug application provides for a new indication for Brukinsa for the
     treatment of adult patients with chronic lymphocytic leukemia (CLL) ..."
That sentence (up to the next section heading such as "APPROVAL & LABELING") is the regulator's own statement of
the change, and is what this script writes into `indication_text` for FDA rows. It also proposes a class
(`letter_class`) and a disease phrase (`letter_phrase`) from wording patterns; both are proposals for the review
layer, not decisions.

Input : raw/fda/letters/approval_letter_text.json   {candidate_id: {letter_url, status, pages_total, text_pages_1_3}}
Output: interim/fda_letter_indications.csv          candidate_id, letter_url, provides_for, letter_class, letter_phrase
"""
import argparse
import csv
import json
import re
from pathlib import Path

HEADING_RE = re.compile(r"\s(?:APPROVAL\s*&\s*LABEL(?:ING)?|APPROVAL AND LABELING|We have completed our review|CONTENT OF LABELING|"
                        r"WAIVER OF|REQUIRED PEDIATRIC|PEDIATRIC REQUIREMENTS|POSTMARKETING REQUIREMENTS|PROMOTIONAL MATERIALS|"
                        r"ADVISORY COMMITTEE|CARTON AND CONTAINER|FULFILLMENT OF POST|LABELING\s{2})", re.I)
PROVIDES_RE = re.compile(r"\bprovides?\s+(?:support\s+)?for\b|\badds?\s+(?:a|the)\s+(?:new\s+)?indication|\bis\s+for\s+(?:a|the)\s+(?:new\s+)?indication|"
                         r"\bexpands?\s+the\s+indication|\bapproval\s+of\s+the\s+(?:new\s+)?indication", re.I)

CLASS_RULES = [
    ("new_indication", re.compile(r"new indication|new therapeutic indication|the following (?:new )?indication|"
                                  r"addition of (?:an|the) indication|add(?:ing|ition of)? (?:a |the )?(?:new )?indication|"
                                  r"indication for (?:the )?(?:treatment|prevention|prophylaxis)", re.I)),
    ("expanded_population", re.compile(r"expan(?:d|sion) of (?:the )?(?:existing |approved |current )?indication|extend(?:ing|s)? the (?:existing |approved |current )?indication|"
                                       r"to include (?:adult|pediatric|patients|children|adolescents)|pediatric patients|patients (?:\d+|one|two|six|twelve) (?:years|months) of age|"
                                       r"expand(?:ed|ing)? (?:the )?(?:age|patient population)|to include (?:the treatment of )?(?:adolescents|children)|"
                                       r"lower(?:ing)? the (?:minimum )?age", re.I)),
    ("commitment_fulfilment", re.compile(r"fulfil?l?ment of (?:the )?postmarketing|accelerated approval to (?:regular|traditional|full) approval|"
                                          r"conversion of .{0,80}accelerated approval|verify clinical benefit|confirmatory", re.I)),
    ("line_extension", re.compile(r"first[- ]line|second[- ]line|earlier line|line of therapy|maintenance treatment|neoadjuvant|adjuvant|perioperative|"
                                  r"in combination with|to include (?:the )?(?:use|combination)", re.I)),
    ("wording_only", re.compile(r"revis(?:e|ion of|ions to) (?:the )?(?:indication|section 1|indications and usage)|update(?:s)? to (?:section 1|the indications and usage)|"
                                r"remov(?:e|al of)|limitation of use|clarif", re.I)),
    ("formulation_or_route", re.compile(r"new (?:dosage form|strength|route|formulation|presentation)|dosing regimen|dosage regimen|dose regimen", re.I)),
]

PHRASE_RES = [
    re.compile(r"new indication[^:]{0,80}?:\s*(.{5,300}?)(?:\.\s|$)", re.I),
    re.compile(r"(?:for|as)\s+(?:the\s+)?(?:treatment|prevention|prophylaxis|management|reduction of the risk)\s+(?:of|for)\s+(?:adult\s+|pediatric\s+|adults?\s+and\s+pediatric\s+)?(?:patients?\s+(?:\d+[^\s]*\s+(?:years|months)\s+(?:of age\s+)?(?:and older\s+)?)?(?:with|who have)\s+)?(.{5,220}?)(?:\s+(?:in|who|whose|following|after|that|which|as)\b|[.;]|$)", re.I),
    re.compile(r"indicated\s+(?:as\s+[^,]{0,60},?\s*)?for\s+(?:the\s+)?(?:treatment\s+of\s+)?(?:adult\s+|pediatric\s+)?(?:patients\s+with\s+)?(.{5,220}?)(?:\s+(?:in|who|whose|following|after)\b|[.;]|$)", re.I),
    re.compile(r"to include\s+(?:the\s+)?(?:treatment\s+of\s+)?(?:adult\s+|pediatric\s+)?(?:patients\s+(?:with|who have)\s+)?(.{5,220}?)(?:\s+(?:in|who|whose|following|after)\b|[.;]|$)", re.I),
]


ANCHOR_RE = re.compile(r"(?:This|These)\s+[\u201c\"]?Prior Approval|(?:This|These)\s+(?:Prior Approval\s+)?(?:supplemental|sNDA|sBLA)|"
                       r"\bPrior Approval\s+supplemental", re.I)


def provides_for(text: str) -> str:
    """The sentence(s) saying what the supplement does: anchored on 'provides for' (or a synonym), falling back to
    the 'This Prior Approval supplemental ... application ...' sentence, and running to the next section heading."""
    m = PROVIDES_RE.search(text) or ANCHOR_RE.search(text)
    if not m:
        return ""
    # back up to the start of the sentence (the previous full stop, or the "Dear ...:" salutation)
    start = max(text.rfind(". ", 0, m.start()), text.rfind(": ", 0, m.start()))
    start = start + 2 if start >= 0 else 0
    rest = text[start:]
    h = HEADING_RE.search(rest, m.start() - start + 10)
    passage = rest[: h.start()] if h else rest[:1500]
    return re.sub(r"\s+", " ", passage).strip()[:1500]


def classify(passage: str) -> str:
    hits = [name for name, rx in CLASS_RULES if rx.search(passage)]
    if not hits:
        return "unclear"
    if "new_indication" in hits:
        return "new_indication"
    return hits[0]


def phrase(passage: str) -> str:
    for rx in PHRASE_RES:
        m = rx.search(passage)
        if m:
            p = m.group(1).strip(" ,:;")
            return re.sub(r"\s+", " ", p)
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--letters", default="raw/fda/letters/approval_letter_text.json")
    ap.add_argument("-o", "--out", default="interim/fda_letter_indications.csv")
    a = ap.parse_args()
    letters = json.loads(Path(a.letters).read_text())
    rows = []
    for cid, rec in letters.items():
        t = rec.get("text_pages_1_3", "") if rec.get("status") == 200 else ""
        pf = provides_for(t)
        rows.append(dict(candidate_id=cid, letter_url=rec.get("letter_url", ""), letter_status=rec.get("status"),
                         provides_for=pf, letter_class=classify(pf) if pf else ("no_letter" if not t else "unclear"),
                         letter_phrase=phrase(pf) if pf else ""))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    from collections import Counter
    print(f"{len(rows)} letters; passage found for {sum(1 for r in rows if r['provides_for'])}; "
          f"classes {dict(Counter(r['letter_class'] for r in rows))}; phrase for {sum(1 for r in rows if r['letter_phrase'])}")


if __name__ == "__main__":
    main()
