# Prospective new-indication approvals, 2023 to date (pre-cleaning candidate set)

Candidate table of regulatory decisions that added an indication to an already-authorised medicine, from
five regulators, for building a prospective drug-repurposing benchmark for knowledge-graph link prediction.

| regulator | what a row is | rows (2023-01-01 to 2026-09-17) |
|---|---|---|
| FDA (CDER) | approved NDA/BLA efficacy supplement whose FDA supplement type is **New Indication** (SE1), plus 2026 BLA efficacy supplements whose sub-type FDA has not yet published; indication text from the approval letter | 272 + 75 unclassified |
| EMA | CHMP positive opinion on an **extension of (therapeutic) indication** (monthly meeting highlights); variation scope and EC decision date from the EPAR procedural-steps PDF where matched (204) | 324 (+9 negative/withdrawn/non-EU, flagged) |
| Health Canada | NOC for a **Supplement to a New Drug Submission (SNDS)** whose reason text mentions an indication | 154 starting with a new-indication phrase + 92 other text matches |
| PMDA (Japan) | approval whose English Notes say "**new indication**" | 173 |
| TGA (Australia) | prescription medicine registration of type **EOI (extension of indications)** | 189 |

`data/candidates_precleaning.csv` has 1,288 rows. It is deliberately *pre-cleaning*: every row is one regulator's
decision, nothing is merged across regulators, indications are not yet ontology-mapped, and line extensions
(new tumour type for a PD-1 inhibitor, paediatric extension) are still in. The FDA definition (efficacy supplement,
sub-type "New Indication") is the anchor; the other four regulators are mapped to the closest thing they publish
(see "Definitions" below).

## Reproduce

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt           # exact versions of the snapshot; requirements-loose.txt for minimums
./run_all.sh                              # offline: re-parses the raw/ snapshot shipped here (about a minute)
NORMALISE=1 OFFLINE=1 ./run_all.sh        # ... plus the identifier mapping from the shipped API cache
./run_all.sh --fetch                      # re-downloads every source first (about 15 minutes; Drugs@FDA is rate-limited)
python -m pytest tests                    # parser unit tests + spot checks of known approvals
python scripts/provenance.py --check PROVENANCE.json   # confirm your rebuild matches the shipped checksums
```

`PROVENANCE.md` gives the timeline of the snapshot, the exact edition or timestamp of every source, the
software versions, and the selection rules in one place; `PROVENANCE.json` holds SHA-256 checksums of every
file. `VERSION`, `CHANGELOG.md` and `CITATION.cff` carry the dataset version (`0.1.0+20260917`).

Every step is one script in `scripts/`, with the source URL, the exact selection rule and the parsing strategy in
its docstring. Raw downloads go to `raw/<regulator>/` with a `MANIFEST.json` (fetch time, URL, byte counts),
per-regulator tables to `interim/`, the merged table to `data/`.

```
raw/normalisation/mondo.sssom.tsv                     MONDO cross-reference mappings (Monarch), used by normalise.py
raw/fda/openfda_efficacy_supplements_2023plus.json   openFDA Drugs@FDA API, EFFICACY supplements >= 2023 (universe)
raw/fda/efficacy_supplements_CY{2023,2024,2025}.pdf   FDA calendar-year efficacy supplement reports (sub-type source)
raw/fda/drugsatfda_supplement_categories.json        Drugs@FDA application pages, "Supplement Categories" (NDA sub-type source)
raw/ema/chmp-highlights-<meeting>.html                40 CHMP meeting-highlights pages, Jan 2023 to Jul 2026 (content block only)
raw/health_canada/noc_*.txt                           NOC data extract (see note on the shipped subset below)
raw/pmda/pmda_list_of_approved_drugs_*.pdf            PMDA "List of Approved Drugs" (see note on the shipped subset below)
raw/tga/tga_eoi_items.json                            TGA EOI registration detail pages, parsed to key/value records
```

Snapshot in this folder was taken on 2026-09-17 (UTC times in the manifests). Two raw files are subsets to keep
the folder small; `run_all.sh --fetch` replaces them with the full downloads and the parsers give identical output:

* `raw/health_canada/*.txt`: the full extract is 32 MB. Shipped: the SNDS rows dated 2023 to 2026 whose reason
  text matches `/indication/i`, and their brand/DIN/ingredient child rows, in the extract's own format
  (`raw/health_canada/MANIFEST.json` records the full-file counts: 37,932 NOCs, 3,145 SNDS in the window, 246 matches).
* `raw/pmda/pmda_list_of_approved_drugs_2004-2026-02_pages1-47.pdf`: pages 1 to 47 of the 207-page PDF
  (everything approved from January 2023 to February 2026; the rest is 2004 to 2022). Pages were copied without
  re-rendering (pdf-lib), so text positions are unchanged.

## Definitions and what each source actually gives you

**FDA.** Universe = every approved CDER supplement with `submission_class_code = EFFICACY` in openFDA (847 in the
window; 217/222/253 in 2023/24/25, matching the FDA annual reports to within a few rows). The efficacy *sub-type*
is not in openFDA. It comes from two places, both kept as separate columns so you can see who said what:
the FDA calendar-year PDF reports (NDA and BLA; 2023 to 2025 available, 2026 published early 2027) and the
Drugs@FDA application pages (`Efficacy-New Indication` etc.; NDAs only, BLAs show as plain "Supplement").
Where both exist they agree on 98% of rows (the rest are naming variants such as "Accelerated Approval" vs
"Accelerated Approval Confirmatory Study"). Consequences: 2026 NDAs are classified from Drugs@FDA; 2026 BLAs
(75 rows) are `unclassified` until the 2026 report appears, and need the approval letter to classify now
(`letter_url` is included). CBER products (vaccines, blood, cell and gene therapies) are not in Drugs@FDA at all.
The report PDFs clip one column on two 2023 pages; `supplement_type_raw` keeps the clipped text and
`supplement_type` the canonical value.

**EMA.** The CHMP highlights list medicines recommended for an extension of indication, with INN and MAH but not
the indication wording. The row date is the CHMP opinion publication date; the European Commission decision
(the legal authorisation) follows about two months later and is on the EPAR page linked in `document_url`
("Changes since initial authorisation"). Negative opinions, withdrawals and EU-M4all (non-EU) opinions are kept
with `classification_flag = excluded_*`. Vaccines have no INN in the source. The September 2026 meeting is not
yet published.

**Health Canada.** No supplement sub-type exists; the closest is an SNDS with a free-text reason. Rows whose
reason *starts* with a new-indication phrase ("New indication:", "Additional indication", "Indication
extension", "Expansion of indication") are `new_indication`; other matches ("Update to the indications ...",
"Remove the following indication", "fulfilment of commitments ... for the following indication") are
`text_match` and need reading. The reason text often quotes the indication verbatim, which is useful. The
extract is bilingual and some non-ASCII characters (≥) are corrupted at source.

**PMDA.** Japan classifies applications, not supplements. The English list's Notes column says "A drug with a
new indication ..." for what the FDA would call SE1; combinations ("new indication and a new dosage", "in an
additional dosage form") are included and the full note is kept. `approval_or_change` = "Change" means partial
change of an existing approval, "Approval" a new product (a new formulation may carry a new indication).
Rows that also mention a new active ingredient are `text_match` (multi-product rows). The English PDF lags:
the current file ends February 2026; approvals in March, June and September 2026 will appear in the next
re-issue. `interim/pmda_all_rows.csv` keeps all 408 approvals in the window for reference.

**TGA.** Cleanest source: registration type EOI is exactly "new use of a registered medicine", and the detail
page prints the *new* indication text. `event_date` is the decision date (the site's year facet is by decision
date); registration date is in `notes`. Search coverage starts in 2018; earlier years are on a separate page.

## Merged table columns (`data/candidates_precleaning.csv`)

| column | meaning |
|---|---|
| `candidate_id` | `FDA:NDA213217-S7`, `EMA:<meeting-slug>:<medicine>`, `HC:<NOC number>`, `PMDA:<date>:<row no>`, `TGA:<page slug>` |
| `regulator` | FDA, EMA, HC, PMDA, TGA |
| `event_date` | ISO date of the decision (FDA supplement approval, CHMP opinion publication, NOC date, PMDA approval date, TGA decision date) |
| `event_type` | the regulator's own label for the decision |
| `product_name`, `active_ingredient`, `sponsor` | as printed by the regulator, not normalised |
| `indication_text` | new-indication text when the regulator publishes it (TGA always, HC and PMDA usually, FDA and EMA never: take it from the label / EPAR) |
| `classification_flag` | `new_indication` (regulator coded it), `text_match` (regex on free text, needs reading), `unclassified` (FDA 2026 BLA), `excluded_*` (EMA negative / withdrawal / non-EU, kept for completeness) |
| `classification_source` | which field or document the flag came from |
| `regulatory_pathway_flags` | orphan, priority, accelerated, provisional, NOC/c where available |
| `source_url`, `document_url` | page the row came from; label, letter or EPAR link |
| `source_row_id` | key into `interim/<regulator>_candidates.csv`, which keeps every regulator-specific field |
| `notes` | carried-over free text |

## Identifier mapping (`scripts/normalise.py`)

`NORMALISE=1 ./run_all.sh` (or `python scripts/normalise.py`) adds KG-ready identifiers and writes
`data/candidates_normalised.csv` plus `data/review_queue.csv`. It needs internet the first time; every API
response is cached in `raw/normalisation/cache.json`, so the same output is reproduced offline afterwards
(`--offline`). The shipped snapshot includes the cache (Name Resolver 1.5.2, Node Normalizer 2.4.1, queried
2026-09-17), so `NORMALISE=1 OFFLINE=1 ./run_all.sh` reproduces `data/candidates_normalised.csv` without
network access. Delete the cache to re-query the live services (about 15 minutes for ~1,900 calls; results can
differ as the Translator indices are rebuilt). `python scripts/normalise.py --plan requests.json` lists the
exact requests a live run would make.

| | primary | also recorded | how |
|---|---|---|---|
| drug | ChEMBL / UNII (always), DrugBank (with the vocabulary file) | PubChem CID, CHEBI, RxCUI, MeSH, UMLS, DrugCentral, InChIKey | FDA rows: openFDA UNII → NCATS Node Normalizer (`drug_chemical_conflate=true`, so salts collapse to the parent drug). Other regulators: ingredient name (salt suffix stripped) → NCATS Name Resolver → Node Normalizer. DrugBank IDs are not in the Translator equivalence sets (licensing), so they are added by joining UNII, then InChIKey, then name to the DrugBank open-data vocabulary CSV, which you download yourself (free account, CC BY-NC 4.0) and pass as `--drugbank-vocab` |
| disease | MONDO | DOID, MeSH, UMLS, OMIM, Orphanet, ICD-10-CM | disease phrase extracted from the indication text (TGA heading line; HC "New indication: X"; PMDA "treatment of X"; else the "indicated for ... X" clause) → Name Resolver restricted to Disease/PhenotypicFeature → MONDO → cross-references from the official `mondo.sssom.tsv` (exact matches plain, broad matches suffixed `~broadMatch`) |

Which graph uses which ID: Hetionet DrugBank/DOID; DRKG DrugBank/MeSH; PrimeKG DrugBank/MONDO; BioKG DrugBank/MeSH
and KEGG; OpenBioLink PubChem CID/DOID; MATRIX Biolink CURIEs (largely DrugBank and CHEBI)/MONDO. Biologics and
vaccines have DrugBank, ChEMBL and UNII entries but no PubChem CID, so they cannot appear in OpenBioLink.

Columns added by `normalise.py` (all `drug_*` values are "; "-joined when a product has several ingredients):

| column | content |
|---|---|
| `drug_query` | ingredient strings sent to Name Resolver (empty for FDA rows, which use the UNII directly) |
| `drug_match` | per ingredient: `openFDA UNII:1.00` or `Name Resolver:<score>` |
| `drug_label` | Node Normalizer preferred label(s) |
| `drug_unii`, `drug_chembl_compound`, `drug_pubchem_compound`, `drug_chebi`, `drug_rxcui`, `drug_mesh`, `drug_umls`, `drug_drugcentral`, `drug_inchikey` | equivalent identifiers from Node Normalizer (drug/chemical conflation on) |
| `drug_drugbank`, `drug_drugbank_source` | DrugBank ID from the vocabulary join and which key matched (`vocab:UNII`, `vocab:InChIKey`, `vocab:name`) |
| `disease_query` | phrase extracted from `indication_text` and sent to Name Resolver |
| `mondo_id`, `mondo_label`, `disease_match` | top MONDO hit and its score |
| `disease_candidates` | top three hits with scores, for review |
| `disease_doid`, `disease_mesh`, `disease_umls`, `disease_omim`, `disease_orphanet`, `disease_icd10cm` | cross-references of the MONDO term from `mondo.sssom.tsv` (`~broadMatch` suffix when not exact) |
| `needs_review`, `review_reason` | see below |

Coverage in the shipped snapshot: UNII for 1,150 rows, ChEMBL for 1,123, DrugBank for 1,169 (from the
Translator cliques alone; the vocabulary join adds more), MONDO for 389 of the 608 rows that carry indication
text (TGA 157, PMDA 136, Health Canada 96). 1,154 rows are in the review queue, 680 of them only because they
have no indication text yet.

`needs_review` is set when: the row has no indication text (all FDA and EMA rows, until the label/EPAR text is
added), no disease phrase could be extracted, the top Name Resolver hit is not a MONDO term, the runner-up
scores at least `--ambiguity` (0.8) of the top hit, the resolved label shares no informative token with the
query, no identifier came back, or a lookup failed. `review_queue.csv`
lists those rows with the top three candidates so the decision is a lookup, not a search. Expect the disease
side to need a human pass regardless: indication phrases carry qualifiers (line of therapy, biomarker,
population) that the resolver either drops or over-fits, and the paper's ontology-distance rule has to be
applied to the reviewed MONDO term, not the raw match.

## Review layer (`review/`, `scripts/apply_review.py`)

The pipeline output is deliberately unreviewed. The review lives in three small files so that every judgement
is visible, attributable and revisable, and a script applies them so the reviewed table is a build product:

| file | rows | what it holds |
|---|---|---|
| `review/review_decisions.csv` | 2,258 | one decision per `(candidate_id, field)`; `field` is `repurposing_class`, `disease` or `drug`; each row carries `rationale`, `reviewer`, `status` (`proposed` until a second reviewer sets `accepted`), `decided_on` |
| `review/disease_label_pins.csv` | 42 | reviewer-chosen MONDO terms for labels whose MONDO name differs (e.g. Pompe disease → glycogen storage disease II; plaque psoriasis → psoriasis, parent) |
| `scripts/apply_review.py` | | applies the decisions to `data/candidates_normalised.csv` and writes `data/candidates_reviewed.csv` and `data/review_pending.csv` |

Decision grammar (documented in the script docstring): `repurposing_class` takes one of `new_indication`,
`expanded_population`, `line_extension`, `ingredient_prior_indication`, `first_indication`, `biosimilar_alignment`,
`wording_only`, `unclear`, `commitment_fulfilment`, `indication_removed`, `formulation_or_route`,
`out_of_scope_veterinary`. `disease` takes a `MONDO:` id, `lookup:<label>` (resolved
through the pins, then an exact match on the MONDO label index from `mondo.sssom.tsv`, then the cached Name
Resolver), `lookup:text` (indication not stated in the source row), `multi:a;b` or `not_disease:<reason>`.
`drug` takes a CURIE, `lookup:<name>[;prefix=P]`, `vaccine:<label>[;id=CURIE]`, `multi:a;b` or
`unresolved:<reason>`. Mapping policy applied throughout: stage, line-of-therapy, biomarker and age qualifiers
are dropped and the disease entity is mapped; vaccines map to the infection prevented and get
`drug_class = vaccine` with a product-level identifier; diagnostic agents, procedural sedation, contraception,
cosmetic uses and disinfectants are `not_disease` and leave scope.

Columns added to `data/candidates_reviewed.csv`:

| column | content |
|---|---|
| `repurposing_class`, `class_source`, `class_rationale` | reviewed class, or the pipeline flag when no decision was needed (`class_source = pipeline`) |
| `mondo_id_final`, `mondo_label_final`, `disease_status`, `disease_decision`, `disease_note` | final MONDO term(s); status is `reviewed_id`, `reviewed_label_pinned`, `reviewed_label_exact`, `reviewed_label_resolver`, `reviewed_multi`, `pipeline` (unflagged pipeline match kept), `not_disease`, `pending_lookup` or `pending_source_text` |
| `drug_id_final`, `drug_label_final`, `drug_drugbank_final`, `drug_class`, `drug_status`, `drug_decision`, `drug_note` | final identifier (DrugBank first, then ChEMBL, PubChem, CHEBI, UNII, ...); `drug_class = vaccine` for product-level vaccine ids |
| `in_scope`, `exclusion_reason` | false for out-of-scope classes, `not_disease` rows and unresolvable drugs |
| `kg_ready` | `in_scope` and class `new_indication` and both identifiers present |

State of the shipped review (three passes, `reviewer = ai-first-pass` / `ai-second-pass`, all `status =
proposed`): 714 of 1,288 rows in scope, 260 `kg_ready`. The first pass classified every FDA row (347) from its
approval letter, every EMA row with a matched EPAR entry (204 of 333) from the variation scope and the 109
Health Canada `text_match` rows from the NOC reason, and resolved disease and drug identifiers. The second pass
(`review/class_review_20260918.py`) re-read every `kg_ready` row at the level of the active ingredient: the
395 Health Canada, PMDA and TGA rows the pipeline had labelled `new_indication` from the regulator's own
category were classified against the ingredient's prior indications, first-pass FDA/EMA decisions were
revised on the same rule, disease terms were corrected or harmonised across regulators (one MONDO term per
disease, whichever regulator reported it), and two Node Normalizer conflations were fixed (fam-trastuzumab
deruxtecan resolved to trastuzumab emtansine; a 9-valent HPV vaccine to coagulation factor VIIa). The third
pass was an independent re-read of every surviving pair against approval histories, cross-checked against the
FY2022 rows of the PMDA list shipped in `raw/pmda/` (which found the September 2022 Japanese approval of
aflibercept for retinopathy of prematurity); it removed ten more pairs, merged split terms, and recorded an
explicit confirmation for every kept row so that no `kg_ready` row carries a pipeline-assigned class. The
same script records all 489 second- and third-pass decisions. 206 in-scope rows remain `pending_source_text`
(129 EMA cards whose variation could not be matched in the procedural-steps PDF, 10 FDA supplements without a
letter on Drugs@FDA, Health Canada NOCs whose reason is just "New indication", and letters whose passage names
another supplement); 73 disease labels and 61 drug names are `pending_lookup` (Name Resolver calls not in the
cache when the snapshot was built; `python scripts/apply_review.py --plan req.json` lists them, a live run
fills them and caches the responses). `data/review_pending.csv` lists exactly what each pending row needs.

Classification rule used throughout, applied to the active ingredient rather than the product:
`new_indication` is a disease that no product containing the ingredient held before, anywhere (the five
regulators, and the FDA/EMA before 2023), and that is not a subtype, stage or parent of a disease it held (a
different MONDO branch); `line_extension` is the same disease or a subtype, stage, line-of-therapy, regimen or
prevention setting of a disease already held; `expanded_population` is an age or weight extension for the
same disease; `ingredient_prior_indication` is new for the product but already held by the ingredient in
another product, or approved for the same pair before 2023-01-01 by a regulator outside the window (a graph
built from pre-2023 sources would already carry the edge); `first_indication` is the first approval of a new
active substance; `biosimilar_alignment` is a biosimilar adding an indication its reference product holds;
`formulation_or_route` is a new presentation carrying an existing indication. Only `new_indication` rows are
`kg_ready`; the class and its rationale are in the table so the rule can be changed without re-reviewing.
Every `ingredient_prior_indication` rationale names the earlier approval (regulator and month). "Anywhere"
means the five jurisdictions covered here; approvals elsewhere (China's NMPA in particular, where tislelizumab
and zanubrutinib had several indications before their first EU approval) are not consulted. Prevention of a
disease by a drug (prophylaxis) counts as an indication for that disease; prevention of another drug's
toxicity does not (`not_disease:conditioning`).

## Remaining cleaning steps (not done here)

1. Match the 129 EMA cards still without a variation scope (the CHMP summary-of-opinion PDF linked from each
   highlights card is the next source), read the 10 FDA supplements that have no letter on Drugs@FDA from the
   label, and run the pending Name Resolver lookups live.
2. Have a second reviewer set `status = accepted` (or change the decision) in `review_decisions.csv`; the
   `reviewer` column is where inter-rater agreement is measured. The second-pass class decisions rest on the
   reviewer's knowledge of each ingredient's approval history; each rationale names the prior approval so it
   can be checked against Drugs@FDA or the EPAR.
3. Collapse across regulators to one drug-indication pair with the earliest decision date and the list of
   regulators (done downstream by `biokgsuite-bib/tools/build_prospective_gold.py`, which also applies the
   ontology-distance rule against each graph's own prior indications).

## Sources

* FDA efficacy supplement reports: https://www.fda.gov/drugs/nda-and-bla-approvals/efficacy-supplement-approvals
* openFDA Drugs@FDA API: https://open.fda.gov/apis/drug/drugsfda/
* Drugs@FDA application pages: https://www.accessdata.fda.gov/scripts/cder/daf/
* EMA CHMP meeting highlights: https://www.ema.europa.eu/en/news?search_api_fulltext=Meeting+highlights+CHMP
* Health Canada NOC data extract: https://www.canada.ca/en/health-canada/services/drugs-health-products/drug-products/notice-compliance/database/data-extract.html (Open Government Licence - Canada)
* PMDA list of approved drugs: https://www.pmda.go.jp/english/review-services/reviews/approved-information/drugs/0002.html
* TGA prescription medicines registrations: https://www.tga.gov.au/resources/prescription-medicines-registrations
