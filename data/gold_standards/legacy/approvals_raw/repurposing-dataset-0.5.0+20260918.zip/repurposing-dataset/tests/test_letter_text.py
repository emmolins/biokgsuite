"""Offline tests for the FDA approval-letter and EMA procedural-steps text extractors."""
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import ema_procedural_steps as E  # noqa: E402
import fda_letter_indication as F  # noqa: E402

LETTER = ("Dear Dr. Chen:  Please refer to your supplemental new drug application (sNDA) dated December 18, 2021 for "
          "Brukinsa (zanubrutinib) capsules.  This Prior Approval supplemental new drug application provides for a new "
          "indication for Brukinsa for the treatment of adult patients with chronic lymphocytic leukemia (CLL) or small "
          "lymphocytic lymphoma (SLL).  APPROVAL & LABEL  We have completed our review of this application.")
LETTER2 = ("Dear Ms. X:  Please refer to your sBLA for Cosentyx.  This Prior Approval supplemental biologics license "
           "application provides support for the use of Cosentyx for the treatment of adult patients with moderate to "
           "severe hidradenitis suppurativa.  APPROVAL & LABELING  We have completed")
LETTER3 = ("Dear Dr. Y:  Please refer to your sNDA for TUKYSA.  This Prior Approval supplemental new drug application adds a "
           "new indication of TUKYSA in combination with trastuzumab for the treatment of adult patients with colorectal "
           "cancer that has progressed.  APPROVAL & LABELING")


def test_provides_for_passage_and_class():
    p = F.provides_for(LETTER)
    assert p.startswith("This Prior Approval") and p.endswith("(SLL).")
    assert F.classify(p) == "new_indication"
    assert "chronic lymphocytic leukemia" in F.phrase(p)
    p2 = F.provides_for(LETTER2)
    assert "hidradenitis suppurativa" in p2 and "We have completed" not in p2
    p3 = F.provides_for(LETTER3)
    assert p3.startswith("This Prior Approval") and F.classify(p3) == "new_indication"
    assert F.provides_for("Dear Sir: nothing relevant here.") == ""


def test_class_rules():
    assert F.classify("provides for the treatment of functional constipation in pediatric patients 6 to 17 years of age.") == "expanded_population"
    assert F.classify("provides for conversion from accelerated approval to traditional approval of X") == "commitment_fulfilment"
    assert F.classify("provides for a new dosing regimen of 375 mg every 3 weeks") == "formulation_or_route"


def test_meeting_end_and_entries():
    assert E.meeting_end("23-26 January 2023") == date(2023, 1, 26)
    assert E.meeting_end("30 January-2 February 2023") == date(2023, 2, 2)
    window = ("II/0030   Extension of indication to include treatment of narcolepsy with or without cataplexy in adolescents "
              "and children from the age of 6 years, based on results from Study P11-06. As a consequence, sections 4.1 of the "
              "SmPC are updated.  C.I.6.a - Change(s) to therapeutic indication(s)  26/01/2023   24/02/2023   SmPC and PL")
    ents = list(E.entries(window))
    assert len(ents) == 1
    scope, op, dec, proc = ents[0]
    assert scope.startswith("Extension of indication to include treatment of narcolepsy")
    assert op == date(2023, 1, 26) and dec == date(2023, 2, 24) and proc == "II/0030"
