"""Offline tests for apply_review.py decision parsing (no network: an in-memory cache with recorded shapes)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import apply_review as A  # noqa: E402


class FakeCache:
    def __init__(self, d):
        self.d, self.missing = d, {}

    def get(self, key, fetch, request=None):
        return self.d.get(key)


LABELS = {"MONDO:0005083": "psoriasis", "MONDO:0004975": "Alzheimer disease", "MONDO:0002026": "candidiasis"}
PINS = {"plaque psoriasis": ("MONDO:0005083", "psoriasis", "parent term")}
CACHE = FakeCache({
    "nr|DiseaseOrPhenotypicFeature|giant cell arteritis": [{"curie": "MONDO:0007059", "label": "giant cell arteritis", "score": 60.0}],
    "nr|ChemicalEntity|semaglutide": [{"curie": "UNII:53AXN4NNHX", "label": "SEMAGLUTIDE", "score": 80.0}],
    "nn|c|UNII:53AXN4NNHX": {"UNII:53AXN4NNHX": {"id": {"identifier": "CHEBI:167574", "label": "semaglutide"},
                                                  "equivalent_identifiers": [{"identifier": "CHEBI:167574"}, {"identifier": "UNII:53AXN4NNHX"},
                                                                             {"identifier": "CHEMBL.COMPOUND:CHEMBL3286699"}]}},
    "nr|ChemicalEntity|covid-19 mrna vaccine": [{"curie": "UMLS:C5889747", "label": "COVID-19 mRNA Vaccine [EPC]", "score": 50.0}],
})


def test_disease_forms():
    assert A.resolve_disease("MONDO:0004975", PINS, LABELS, CACHE)[:3] == ("MONDO:0004975", "Alzheimer disease", "reviewed_id")
    assert A.resolve_disease("lookup:plaque psoriasis", PINS, LABELS, CACHE)[:3] == ("MONDO:0005083", "psoriasis", "reviewed_label_pinned")
    assert A.resolve_disease("lookup:Candidiasis", PINS, LABELS, CACHE)[:3] == ("MONDO:0002026", "candidiasis", "reviewed_label_exact")
    assert A.resolve_disease("lookup:giant cell arteritis", PINS, LABELS, CACHE)[:3] == ("MONDO:0007059", "giant cell arteritis", "reviewed_label_resolver")
    assert A.resolve_disease("lookup:not in cache", PINS, LABELS, CACHE)[2] == "pending_lookup"
    assert A.resolve_disease("lookup:text", PINS, LABELS, CACHE)[2] == "pending_source_text"
    assert A.resolve_disease("not_disease:diagnostic", PINS, LABELS, CACHE)[2] == "not_disease"
    mid, _, status, _ = A.resolve_disease("multi:MONDO:0004975;lookup:Candidiasis", PINS, LABELS, CACHE)
    assert mid == "MONDO:0004975; MONDO:0002026" and status == "reviewed_multi"
    assert A.resolve_disease("multi:MONDO:0004975;lookup:text", PINS, LABELS, CACHE)[2] == "pending_source_text"


def test_drug_forms():
    pid, label, db, cls, status, _ = A.resolve_drug("lookup:semaglutide", CACHE)
    assert pid == "CHEMBL.COMPOUND:CHEMBL3286699" and status == "reviewed_lookup" and cls == ""
    pid, _, _, _, status, _ = A.resolve_drug("lookup:semaglutide;prefix=UNII", CACHE)
    assert status == "reviewed_lookup" and pid.startswith("CHEMBL.COMPOUND:")  # preferred id comes from the clique, prefix only picks the hit
    pid, _, _, cls, status, _ = A.resolve_drug("vaccine:COVID-19 mRNA vaccine (Comirnaty)", CACHE)
    assert pid == "UMLS:C5889747" and cls == "vaccine" and status == "reviewed_vaccine_resolver"
    assert A.resolve_drug("vaccine:unknown thing", CACHE)[4] == "pending_lookup"
    assert A.resolve_drug("unresolved:veterinary", CACHE)[4] == "unresolved"
    pid, _, _, _, status, _ = A.resolve_drug("multi:lookup:semaglutide;lookup:semaglutide", CACHE)
    assert status == "reviewed_multi" and pid.count(";") == 1


def test_pipeline_drug_id_priority():
    row = {"drug_drugbank": "", "drug_chembl_compound": "CHEMBL1; CHEMBL2", "drug_unii": "X"}
    assert A.pipeline_drug_id(row) == "CHEMBL.COMPOUND:CHEMBL1"
    assert A.pipeline_drug_id({"drug_drugbank": "DB1", "drug_chembl_compound": "CHEMBL1"}) == "DRUGBANK:DB1"
