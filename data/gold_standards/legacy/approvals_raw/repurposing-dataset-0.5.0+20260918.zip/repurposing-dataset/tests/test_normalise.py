"""Offline tests for normalise.py using recorded-shape API responses (Name Resolver / Node Normalizer)."""
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import normalise as N  # noqa: E402

NN_SEMAGLUTIDE = {"UNII:53AXN4NNHX": {"id": {"identifier": "CHEBI:167574", "label": "semaglutide"},
                  "equivalent_identifiers": [{"identifier": "CHEBI:167574"}, {"identifier": "UNII:53AXN4NNHX"},
                                             {"identifier": "INCHIKEY:YAADDGYZMCRWRC-CIIFZSTISA-N"}, {"identifier": "CHEMBL.COMPOUND:CHEMBL3286699"},
                                             {"identifier": "PUBCHEM.COMPOUND:56843331"}, {"identifier": "RXCUI:1991302"},
                                             {"identifier": "MESH:C000587985"}, {"identifier": "UMLS:C3491194"}], "type": ["biolink:SmallMolecule"]}}
NR_OBESITY = [{"curie": "MONDO:0011122", "label": "obesity disorder", "score": 55.2, "types": ["biolink:Disease"]},
              {"curie": "MONDO:0005015", "label": "diabetes mellitus", "score": 20.1, "types": ["biolink:Disease"]}]


def test_phrase_extraction():
    assert N.extract_disease_phrase("TGA", "Ankylosing Spondylitis (AS)\nXELJANZ is indicated for ...") == "Ankylosing Spondylitis (AS)"
    assert N.extract_disease_phrase("HC", "New indication: HER2-Low Breast Cancer: ENHERTU as monotherapy is indicated ...") == "HER2-Low Breast Cancer"
    assert N.extract_disease_phrase("PMDA", "A drug with a new indication for the treatment of mantle cell lymphoma. [Orphan drug]") == "mantle cell lymphoma"
    assert N.extract_disease_phrase("TGA", "KALYDECO is indicated for the treatment of cystic fibrosis (CF) in patients aged 4 months") == "cystic fibrosis (CF)"
    assert N.extract_disease_phrase("HC", "Expand the indication") == ""


def test_drug_name_cleaning():
    assert N.clean_drug_name("cabozantinib (S)-malate") == "cabozantinib"
    assert N.clean_drug_name("Osimertinib mesilate") == "Osimertinib"
    assert N.clean_drug_name("Faricimab (genetical recombination)") == "Faricimab"
    assert N.split_ingredients("formoterol / glycopyrronium bromide / budesonide") == ["formoterol", "glycopyrronium bromide", "budesonide"]
    assert N.split_ingredients("EMTRICITABINE; TENOFOVIR ALAFENAMIDE") == ["EMTRICITABINE", "TENOFOVIR ALAFENAMIDE"]


def test_equivalents_shape():
    eq, label = N.equivalents(NN_SEMAGLUTIDE, "UNII:53AXN4NNHX")
    assert eq["INCHIKEY"] == ["YAADDGYZMCRWRC-CIIFZSTISA-N"] and eq["CHEMBL.COMPOUND"] == ["CHEMBL3286699"] and label == "semaglutide"


def test_end_to_end_offline(tmp_path, monkeypatch):
    """Run normalise.py --offline against a two-row table and a hand-made cache."""
    work = tmp_path
    (work / "raw/normalisation").mkdir(parents=True)
    (work / "interim").mkdir()
    (work / "data").mkdir()
    (work / "raw/normalisation/mondo.sssom.tsv").write_text(
        "subject_id\tsubject_label\tpredicate_id\tobject_id\tobject_label\tmapping_justification\n"
        "MONDO:0011122\tobesity disorder\tskos:exactMatch\tDOID:9970\tobesity\tsemapv:UnspecifiedMatching\n"
        "MONDO:0011122\tobesity disorder\tskos:exactMatch\tmesh:D009765\tObesity\tsemapv:UnspecifiedMatching\n")
    cache = {"nn|c|UNII:53AXN4NNHX": NN_SEMAGLUTIDE,
             "nr|" + N.DISEASE_TYPES + "|obesity": NR_OBESITY,
             "nr|" + N.DRUG_TYPES + "|semaglutide": [{"curie": "CHEBI:167574", "label": "semaglutide", "score": 90.0}],
             "nn|c|CHEBI:167574": {"CHEBI:167574": NN_SEMAGLUTIDE["UNII:53AXN4NNHX"]}}
    (work / "raw/normalisation/cache.json").write_text(json.dumps(cache))
    (work / "vocab.csv").write_text("DrugBank ID,Accession Numbers,Common name,CAS,UNII,Synonyms,Standard InChI Key\n"
                                    "DB13928,,Semaglutide,910463-68-2,53AXN4NNHX,Semaglutide | Ozempic,YAADDGYZMCRWRC-CIIFZSTISA-N\n")
    with open(work / "interim/fda_candidates.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appl_no", "suppl_no", "unii"]); w.writeheader()
        w.writerow({"appl_no": "215256", "suppl_no": "5", "unii": "53AXN4NNHX"})
    fields = ["candidate_id", "regulator", "event_date", "event_type", "product_name", "active_ingredient", "sponsor",
              "indication_text", "classification_flag", "classification_source", "regulatory_pathway_flags",
              "source_url", "document_url", "source_row_id", "notes"]
    with open(work / "data/candidates_precleaning.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        w.writerow({**{k: "" for k in fields}, "candidate_id": "FDA:NDA215256-S5", "regulator": "FDA", "active_ingredient": "SEMAGLUTIDE", "source_row_id": "215256-5"})
        w.writerow({**{k: "" for k in fields}, "candidate_id": "TGA:wegovy", "regulator": "TGA", "active_ingredient": "semaglutide",
                    "indication_text": "Obesity\nWEGOVY is indicated as an adjunct to diet for weight management"})
    subprocess.run([sys.executable, str(ROOT / "scripts/normalise.py"), "--offline", "--drugbank-vocab", "vocab.csv"], cwd=work, check=True)
    out = {r["candidate_id"]: r for r in csv.DictReader(open(work / "data/candidates_normalised.csv"))}
    fda, tga = out["FDA:NDA215256-S5"], out["TGA:wegovy"]
    assert fda["drug_drugbank"] == "DB13928" and fda["drug_drugbank_source"] == "vocab:UNII" and fda["drug_match"].startswith("openFDA UNII")
    assert "no indication text" in fda["review_reason"]
    assert tga["drug_drugbank"] == "DB13928" and tga["drug_query"] == "semaglutide"
    assert tga["mondo_id"] == "MONDO:0011122" and tga["disease_doid"] == "9970" and tga["disease_mesh"] == "D009765"
    assert tga["needs_review"] == "False"
