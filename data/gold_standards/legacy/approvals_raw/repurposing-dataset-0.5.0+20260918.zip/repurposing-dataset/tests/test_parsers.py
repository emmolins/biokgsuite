"""Offline tests for the parsing functions used by the fetch scripts, plus end-to-end checks on the shipped raw data.
Run:  python -m pytest tests -q
"""
import csv
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import fetch_drugsatfda  # noqa: E402
import fetch_tga  # noqa: E402
from fda_parse_efficacy_pdf import canonical_type  # noqa: E402


def test_tga_detail_parser():
    rec = fetch_tga.parse_detail((ROOT / "tests/fixtures/tga_detail_min.html").read_text(), "u")
    assert rec["Product name"] == "FABHALTA"
    assert rec["Decision date"] == "2025-12-19T12:00:00Z"
    assert rec["Registration type"] == "EOI"
    assert "complement 3 glomerulopathy" in rec["Indication"]
    assert "Orphan drug" in rec


def test_drugsatfda_table_parser():
    rows = fetch_drugsatfda.parse_supplement_table((ROOT / "tests/fixtures/drugsatfda_min.html").read_text(), "213217", 2023)
    assert [r["submission"] for r in rows] == ["SUPPL-11", "SUPPL-7"]
    assert rows[0]["category"] == "Efficacy-New Indication"
    assert rows[0]["docs"][1]["t"] == "Letter (PDF)"


def test_canonical_type():
    assert canonical_type("Labeling Change With Clinical") == ("Labeling Change With Clinical Data", "")
    assert canonical_type("Manufacturing Change With CAMJE") == ("Manufacturing Change With Clinical Data", "CAMJE")
    assert canonical_type("New Indication") == ("New Indication", "")
    assert canonical_type("") == ("", "")


def test_fda_pdf_parse_known_rows(tmp_path):
    out = tmp_path / "pdf.csv"
    subprocess.run([sys.executable, "scripts/fda_parse_efficacy_pdf.py", "raw/fda/efficacy_supplements_CY2023.pdf", "-o", str(out)], cwd=ROOT, check=True)
    rows = list(csv.DictReader(open(out)))
    assert len(rows) >= 215
    bru = [r for r in rows if r["appl_no"] == "213217" and r["suppl_no"] == "7"][0]
    assert bru["supplement_type"] == "New Indication" and bru["approval_date"] == "1/19/2023"
    assert all(r["priority"] in ("S", "P", "U") for r in rows)


def test_candidates_have_known_approvals():
    fda = list(csv.DictReader(open(ROOT / "interim/fda_candidates.csv")))
    assert any(r["appl_no"] == "213217" and r["suppl_no"] == "7" and r["is_new_indication_any"] == "True" for r in fda)
    ema = list(csv.DictReader(open(ROOT / "interim/ema_candidates.csv")))
    assert any(r["medicine"] == "Dupixent" and r["meeting"].endswith("January 2023") for r in ema)
    hc = list(csv.DictReader(open(ROOT / "interim/health_canada_candidates.csv")))
    assert any(r["brand_names"] == "ENHERTU" and r["noc_date"] == "2023-01-06" for r in hc)
    tga = list(csv.DictReader(open(ROOT / "interim/tga_candidates.csv")))
    assert any(r["product_name"] == "ENHERTU" and r["decision_date"] == "2023-01-24" for r in tga)
    pmda = list(csv.DictReader(open(ROOT / "interim/pmda_candidates.csv")))
    assert any("Enhertu" in r["brand_names"] and r["approval_date"] == "2023-03-27" for r in pmda)


def test_merged_table_ids_unique_and_dated():
    rows = list(csv.DictReader(open(ROOT / "data/candidates_precleaning.csv")))
    ids = [r["candidate_id"] for r in rows]
    assert len(ids) == len(set(ids))
    assert all(len(r["event_date"]) == 10 and r["event_date"] >= "2023-01-01" for r in rows)
    assert {r["regulator"] for r in rows} == {"FDA", "EMA", "HC", "PMDA", "TGA"}
