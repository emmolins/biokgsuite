#!/usr/bin/env bash
# Rebuild the pre-cleaning candidate dataset end to end.
#
#   ./run_all.sh            # parse the raw/ snapshot shipped in this folder (offline, ~1 min)
#   ./run_all.sh --fetch    # re-download every source first (needs internet; ~15 min, Drugs@FDA is rate-limited)
#   NORMALISE=1 ./run_all.sh    # also run scripts/normalise.py (identifier mapping; needs internet the first time)
#
# Steps are ordinary scripts in scripts/; run any of them by hand to debug one regulator.
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=scripts
START=2023-01-01

if [[ "${1:-}" == "--fetch" ]]; then
  echo "== fetching raw sources"
  python scripts/fetch_openfda.py --start ${START//-/} -o raw/fda/openfda_efficacy_supplements_2023plus.json
  python scripts/fetch_fda_pdfs.py --years 2023 2024 2025 2026 -o raw/fda
  python scripts/fetch_drugsatfda.py --openfda raw/fda/openfda_efficacy_supplements_2023plus.json -o raw/fda/drugsatfda_supplement_categories.json
  python scripts/fetch_ema.py --start-year 2023 -o raw/ema
  python scripts/fetch_health_canada.py -o raw/health_canada
  python scripts/fetch_pmda.py -o raw/pmda
  python scripts/fetch_tga.py --years 2023 2024 2025 2026 -o raw/tga/tga_eoi_items.json
fi

mkdir -p interim data
echo "== FDA"
python scripts/fda_parse_efficacy_pdf.py raw/fda/efficacy_supplements_CY*.pdf -o interim/fda_efficacy_supplements_pdf.csv
python scripts/fda_build.py --start $START -o interim/fda_candidates.csv
echo "== EMA"
python scripts/ema_parse_chmp_highlights.py raw/ema/chmp-highlights-*.html -o interim/ema_candidates.csv
echo "== Health Canada"
python scripts/health_canada_extract.py --raw raw/health_canada --start $START -o interim/health_canada_candidates.csv
echo "== PMDA"
PMDA_PDF=$(ls raw/pmda/*.pdf | head -1)
python scripts/pmda_parse_approved_list.py "$PMDA_PDF" --start $START -o interim/pmda_candidates.csv
python scripts/pmda_parse_approved_list.py "$PMDA_PDF" --start $START --all-rows -o interim/pmda_all_rows.csv
echo "== TGA"
python scripts/tga_build.py --items raw/tga/tga_eoi_items.json --start $START -o interim/tga_candidates.csv
echo "== FDA approval-letter text and EMA procedural-steps text (from raw/, no network)"
python scripts/fda_letter_indication.py --letters raw/fda/letters/approval_letter_text.json -o interim/fda_letter_indications.csv
python scripts/ema_procedural_steps.py --candidates interim/ema_candidates.csv -o interim/ema_procedural_indications.csv
echo "== merge"
python scripts/merge_candidates.py --interim interim -o data/candidates_precleaning.csv
echo "done: data/candidates_precleaning.csv"

# Optional: attach DrugBank/ChEMBL/PubChem/UNII/RxCUI and MONDO/DOID/MeSH/UMLS/OMIM identifiers.
# Needs network for NCATS Name Resolver + Node Normalizer the first time; responses are cached in
# raw/normalisation/cache.json, after which `--offline` reproduces the same output.
if [[ "${NORMALISE:-0}" == "1" ]]; then
  echo "== normalise (Translator APIs + MONDO SSSOM)"
  [[ -f raw/normalisation/mondo.sssom.tsv ]] || curl -sSL -o raw/normalisation/mondo.sssom.tsv \
     https://raw.githubusercontent.com/monarch-initiative/mondo/d50a5d1a6d728fe52063b9f84f9a19cb56ca7333/src/ontology/mappings/mondo.sssom.tsv
  python scripts/normalise.py ${OFFLINE:+--offline}
  echo "== apply review decisions (review/ -> data/candidates_reviewed.csv)"
  python scripts/apply_review.py ${OFFLINE:+--offline}
fi

# Provenance record (checksums + environment); compare a rebuild with: python scripts/provenance.py --check PROVENANCE.json
python scripts/provenance.py -o PROVENANCE.json
