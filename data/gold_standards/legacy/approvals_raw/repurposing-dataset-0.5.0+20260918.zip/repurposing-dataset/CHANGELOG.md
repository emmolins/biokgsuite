# Changelog

## 0.5.0+20260918 (2026-09-18)

Third review pass: an independent re-read of every pair that survived the second pass, cross-checked against
the FY2022 rows of the shipped PMDA list. Ten pairs left (`ingredient_prior_indication` or `line_extension`:
zanubrutinib CLL, relugolix endometriosis, canakinumab gout, nitisinone alkaptonuria, cisplatin urothelial
carcinoma, atropine myopia, aflibercept retinopathy of prematurity, bempedoic acid ASCVD, valemetostat PTCL;
obinutuzumab CRS pre-treatment is `not_disease`), gastric/GEJ adenocarcinoma and CLL/SLL are one term each,
polyarticular JIA one term, and 135 kept rows carry an explicit confirmation so every `kg_ready` row has a
reviewed class. `scripts/ema_procedural_steps.py` now keeps every EPAR variation scope adopted at one CHMP
meeting (34 cards gained text), which surfaced three more indications (Jardiance CKD, Tremfya Crohn disease,
Mekinist differentiated thyroid cancer, Rinvoq alopecia areata) and the axial spondyloarthritis scope of the
April 2023 Bimzelx opinion. `kg_ready` 275 -> 260; in scope 732 -> 714. MINOR bump: rules and one parser
changed; rows, identifiers and columns unchanged.

## 0.4.0+20260918 (2026-09-18)

Second review pass at the active-ingredient level (`review/class_review_20260918.py`, 321 decisions, `reviewer =
ai-second-pass`). The 395 Health Canada, PMDA and TGA rows that the pipeline had classed `new_indication` from
the regulator's own category are now classified against the ingredient's prior indications (line extensions,
population extensions, indications the ingredient already held in another product or before 2023); 32 FDA/EMA
first-pass classes revised on the same rule; 20 disease terms corrected or harmonised across regulators; two
Node Normalizer conflations fixed (trastuzumab deruxtecan, 9-valent HPV vaccine). New classes
`ingredient_prior_indication` and `first_indication` (both out of scope). `kg_ready` 557 -> 275; in scope
969 -> 732. MINOR bump: the classification rule changed; rows, identifiers and columns unchanged.

## 0.3.0+20260917 (2026-09-17)

Indication text for FDA and EMA rows. `raw/fda/letters/approval_letter_text.json` (337 approval letters, pages 1
to 3) and `raw/ema/procedural_steps/*.json` (EPAR procedural-steps text windows, current and archive) are new raw
inputs; `scripts/fda_letter_indication.py` and `scripts/ema_procedural_steps.py` turn them into
`interim/fda_letter_indications.csv` and `interim/ema_procedural_indications.csv`, which `merge_candidates.py`
now reads into `indication_text` (335 FDA and 204 EMA rows filled), `document_url` (letter / procedural-steps
PDF) and `notes` (procedure number, EC decision date). Review: 1,102 new decisions (class and disease for every
FDA row and every matched EMA row); new class `biosimilar_alignment`; 14 more label pins. `kg_ready` 414 -> 557.
MINOR bump: selection rules unchanged, rows unchanged, columns unchanged.

## 0.2.0+20260917 (2026-09-17)

Adds the review layer: `review/review_decisions.csv` (733 decisions: 109 Health Canada classification, 451
disease, 173 drug), `review/disease_label_pins.csv`, `scripts/apply_review.py` and the outputs
`data/candidates_reviewed.csv` (new columns `repurposing_class`, `mondo_id_final`, `drug_id_final`, `in_scope`,
`kg_ready`, ...) and `data/review_pending.csv`. Schema of `candidates_precleaning.csv` and
`candidates_normalised.csv` unchanged. MINOR bump because rows and identifiers are unchanged and only a
reviewed layer is added; selection rules unchanged.

## 0.1.0+20260917 (2026-09-17)

First snapshot. Five regulators (FDA, EMA, Health Canada, PMDA, TGA), window 2023-01-01 to 2026-09-17,
1,288 pre-cleaning rows. Identifier mapping via NCATS Name Resolver 1.5.2 / Node Normalizer 2.4.1 and
MONDO release v2026-09-01 (see PROVENANCE.md section 3 for every source edition).
