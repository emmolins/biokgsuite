# Changelog

## 0.2.0+20260917 (2026-09-17)

Adds the review layer: `review/review_decisions.csv` (733 decisions: 109 Health Canada classification, 451
disease, 173 drug), `review/disease_label_pins.csv`, `scripts/apply_review.py` and the outputs
`data/candidates_reviewed.csv` (new columns `repurposing_class`, `mondo_id_final`, `drug_id_final`, `in_scope`,
`kg_ready`, ...) and `data/review_pending.csv`. Schema of `candidates_precleaning.csv` and
`candidates_normalised.csv` unchanged. MINOR bump because rows and identifiers are unchanged and only a
reviewed layer is added; selection rules unchanged.

## 0.1.0+20260917 (2026-09-17)

First snapshot. Five regulators (FDA, EMA, Health Canada, PMDA, TGA), window 2023-01-01 to 2026-09-17,
1,288 pre-cleaning rows. Identifier mapping via NCATS Name Resolver 1.5.2 / Node Normalizer 2.4.1 and
MONDO release v2026-09-01 (see PROVENANCE.md section 3 for every source edition).
