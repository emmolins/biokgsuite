# Provenance and reproducibility record

Dataset version: see `VERSION` (semantic version + snapshot date). Machine-readable companion: `PROVENANCE.json`
(SHA-256 and size of every file under `raw/`, `interim/`, `data/`, `scripts/`, `tests/`, `review/`; software versions; the
per-source manifests). Regenerate with `python scripts/provenance.py`; verify a rebuild with
`python scripts/provenance.py --check PROVENANCE.json`.

## 1. What "reproducible" means here, in three layers

1. **Bit-for-bit from the shipped snapshot.** `./run_all.sh` re-parses the files in `raw/` and must reproduce
   `interim/` and `data/` exactly (checksums in `PROVENANCE.json`). This depends only on the pinned Python
   packages below, not on the internet.
2. **Same result from a fresh download of the same source editions.** `./run_all.sh --fetch` re-downloads
   every source. Where a source is versioned (FDA calendar-year reports, PMDA PDF edition, MONDO release,
   CHMP pages) the result is identical; where a source is a live database (openFDA, Drugs@FDA, Health Canada
   NOC extract, TGA search) later downloads contain later approvals and occasional back-corrections, so counts
   grow. Section 3 records the exact edition or timestamp of each source used for this snapshot.
3. **Same method on a later date.** The scripts encode the selection rules (which supplement types, which
   regex on which field), so a re-run in a year is the same method applied to a longer window.

## 2. Timeline of this snapshot (all times UTC, 2026-09-17)

| time | step | tool used for the snapshot | script that reproduces it |
|---|---|---|---|
| 14:36 | FDA calendar-year efficacy supplement reports 2023, 2024, 2025 downloaded | HTTP GET | `scripts/fetch_fda_pdfs.py` |
| 14:37 | openFDA Drugs@FDA query for EFFICACY supplements dated 2023-01-01 or later; 1,157 applications returned, 473 kept after per-supplement filter (847 supplements) | openFDA API, `last_updated` = 2026-09-16 | `scripts/fetch_openfda.py` |
| 14:39 to 14:41 | Health Canada NOC extract files downloaded (server Last-Modified 2026-09-11 14:08 UTC) | HTTP GET | `scripts/fetch_health_canada.py` |
| 14:41 to 14:48 | Drugs@FDA application pages for the 339 NDAs in the openFDA universe (1,202 supplement rows with categories) | HTTP GET, sequential, one retry pass after HTTP 403 rate limiting | `scripts/fetch_drugsatfda.py` |
| 14:48 to 14:51 | 40 CHMP meeting-highlights pages (meetings 23 Jan 2023 to 20 Jul 2026) | HTTP GET | `scripts/fetch_ema.py` |
| 14:55 | PMDA "List of Approved Drugs, April 2004 to February 2026" PDF (file 000281190.pdf, 207 pages); pages 1 to 47 kept | HTTP GET; page subset with pdf-lib 1.17.1 | `scripts/fetch_pmda.py` (full file) |
| 14:57 to 15:00 | TGA EOI registrations 2023 to 2026: 4 year facets, 13 listing pages, 189 detail pages | HTTP GET | `scripts/fetch_tga.py` |
| 15:05 to 15:20 | parsers written and validated; clean rebuild; 6 tests pass | | `run_all.sh`, `tests/` |
| 17:46 | MONDO SSSOM mapping file downloaded from the mondo repository at commit `d50a5d1a6d728fe52063b9f84f9a19cb56ca7333` (2026-09-01, = release v2026-09-01); SHA-256 `317ac4bf...ef302f` | HTTP GET | `run_all.sh` (NORMALISE=1) |
| 17:58 to 18:35 | Name Resolver 1.5.2 and Node Normalizer 2.4.1 queried: 182 UNII normalisations, 837 name/phrase lookups (`biolink_type` = ChemicalEntity or DiseaseOrPhenotypicFeature, limit 5, autocomplete off), 390 normalisations of the resolved CURIEs (conflate + drug_chemical_conflate on); 1,409 cached responses, 0 HTTP errors | Translator APIs (same query strings as the script) | `scripts/normalise.py` |
| 18:40 to 19:05 | review first pass: 109 Health Canada `text_match` rows classified from the NOC reason text; 451 disease decisions (232 flagged matches, 219 rows without an extractable phrase) and 173 drug decisions (106 distinct ingredient strings) recorded in `review/review_decisions.csv`; 28 label pins; `scripts/apply_review.py` written and run offline | manual review against the cached Name Resolver candidates and the MONDO label index (no new API calls) | `scripts/apply_review.py --offline` |

The snapshot requests were issued from a browser session rather than by the fetch scripts themselves (the
build environment could not open direct connections to the regulators); the scripts issue the same HTTP
requests to the same URLs and were validated against the saved responses (`tests/`). Two files are page or
row subsets of the originals, documented in README "Reproduce"; `--fetch` restores the full files and the
parsers give identical output.

## 3. Source editions used

| source | edition / state used | how to cite the edition | changes over time |
|---|---|---|---|
| FDA calendar-year efficacy supplement reports | CY2023 (PDF created 2024-03-14, "As of December 31, 2023"), CY2024 (created 2025-02-13), CY2025 (created 2026-02-27); media ids 177086, 185465, 191372 | file creation dates above; SHA-256 in PROVENANCE.json | static once published; CY2026 expected early 2027 |
| openFDA Drugs@FDA endpoint | `meta.last_updated` = 2026-09-16, queried 2026-09-17 14:37 UTC | quote the `last_updated` value | live; new supplements and occasional corrections weekly |
| Drugs@FDA application pages | fetched 2026-09-17 14:41 to 14:48 UTC | fetch time | live; categories for recent supplements can be added or corrected |
| EMA CHMP meeting highlights | 40 pages, meetings 2023-01-23/26 through 2026-07-20/23; page `published` dates 2023-01-27 to 2026-07-24 | page URLs in `raw/ema/MANIFEST.json` | static once published; new page each month (no August meeting) |
| Health Canada NOC data extract | files with server Last-Modified 2026-09-11 14:08 UTC; 37,932 NOCs, of which 8,354 dated 2023 to 2026, 3,145 SNDS, 246 matching | Last-Modified date | live, updated weekly |
| PMDA List of Approved Drugs | edition "April 2004 to February 2026", file 000281190.pdf, 207 pages | edition label on page 1 | re-issued a few times a year under a new file number; each edition is cumulative |
| TGA prescription medicines registrations | fetched 2026-09-17 14:57 to 15:00 UTC; listing page "Last updated 12 August 2026"; EOI facet counts 46 / 41 / 75 / 27 for 2023 / 2024 / 2025 / 2026 | fetch time and facet counts | live |
| MONDO mappings (mondo.sssom.tsv) | repository commit d50a5d1 (2026-09-01), release v2026-09-01 | commit and release tag | monthly releases |
| NCATS Name Resolver | deployed version 1.5.2 (from `/openapi.json`) on 2026-09-17 | version + date; responses cached in `raw/normalisation/cache.json` | index rebuilt with each Babel release; scores and ranks can change |
| NCATS Node Normalizer | deployed version 2.4.1 on 2026-09-17 | as above | as above |
| DrugBank open-data vocabulary | not included (licence); record the DrugBank release you download (e.g. 5.1.x, date) in `normalisation_provenance.json` via `--drugbank-vocab` | DrugBank release number | quarterly-ish releases |

## 4. Software environment used for the snapshot

Python 3.11.15 on Linux; requests 2.33.1, beautifulsoup4 4.14.3, lxml 6.1.0, pdfplumber 0.11.9
(pdfminer.six 20251230, pypdfium2 5.7.1), pandas 3.0.2, pytest 9.1.1; poppler pdftotext 24.02.0 (used only for
manual inspection, not by the pipeline). `requirements.txt` pins these versions; `requirements-loose.txt` gives
the minimum versions if you need to install on a newer Python.

Parsing PDFs is the step most sensitive to library versions: `pdfplumber` word and table extraction can change
between releases. If a rebuild on other versions changes `interim/fda_efficacy_supplements_pdf.csv` or
`interim/pmda_*.csv`, `python scripts/provenance.py --check PROVENANCE.json` will list the file; compare row
counts and the `supplement_type` / `notes` distributions before trusting the rebuild.

## 5. Selection rules, stated once

* **FDA**: supplement with `submission_type = SUPPL`, `submission_class_code = EFFICACY`, `submission_status = AP`,
  `submission_status_date >= 20230101` in openFDA; sub-type "New Indication" from the calendar-year report
  and/or "Efficacy-New Indication" on the Drugs@FDA page. CDER only (Drugs@FDA scope).
* **EMA**: any medicine card under a CHMP highlights section whose heading matches
  `extensions? of (therapeutic )?indications?` or `new therapeutic indications?`; polarity and "outside the EU"
  are taken from the heading and flagged, not dropped.
* **Health Canada**: `NOC_ENG_SUBMISSION_TYPE = "Supplement to a New Drug Submission (SNDS)"`, `NOC_DATE` in
  window, and `/indication/i` in `NOC_ENG_REASON_SUPPLEMENT` or `NOC_ENG_REASON_SUBMISSION`; "starts with a
  new-indication phrase" sub-flag per `merge_candidates.py`.
* **PMDA**: rows of the approved-drugs table with approval date in window and `\bnew indications?\b` in Notes.
* **TGA**: registrations with Registration type = EOI and decision-date year facet 2023 to 2026.
* **Review**: `scripts/apply_review.py` docstring (decision grammar, resolution order for `lookup:` labels, scope
  rule). Every decision is a row in `review/review_decisions.csv` with a rationale and reviewer; the reviewed
  table is regenerated from those rows, never edited by hand.
* **Identifiers**: `scripts/normalise.py` docstring (Name Resolver types, conflation flag, phrase extraction
  regexes, ambiguity rule = runner-up score at least 0.8 of the top score, label-mismatch review trigger).
  Cached responses are trimmed to the fields the pipeline reads (Name Resolver: no `synonyms`/`highlighting`/
  `taxa`; Node Normalizer: only the identifier prefixes listed in `NN_KEEP`, at most 5 per prefix, with the
  original clique size kept as `n_equivalent_identifiers_total`); the live code applies the same trimming, so a
  fresh run writes cache entries of the same shape.

## 6. Versioning and citation

The dataset is versioned `MAJOR.MINOR.PATCH+YYYYMMDD` in `VERSION` (`CHANGELOG.md` lists changes). A new
snapshot with the same rules is a MINOR bump; a change to a selection rule or schema is MAJOR. Cite as in
`CITATION.cff`, and cite the source editions in Section 3 when the numbers matter for a claim. When you
deposit (Zenodo or similar), include `PROVENANCE.json` and `raw/normalisation/cache.json` so the identifier
mapping is frozen with the data.
